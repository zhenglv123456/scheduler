 CREATE TABLE if not exists xxl_job.`flink_job` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '作业名',
  `status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '实例状态',
  `cron` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '调度cron',
  `update_user` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '更新者',
  `update_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '更新时间',
  `pre_schedule_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '上次执行调度时间',
  `next_schedule_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '下次执行调度时间',
  `create_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建时间',
  `dependency_conf` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '调度依赖配置',
  `statement` text COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '任务sql',
  `create_user` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建者',
  `avg_duration` bigint DEFAULT NULL COMMENT '执行平均耗时',
  `priority` int DEFAULT NULL,
    `curr_time` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
    `resource_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='调度任务表'
;

INSERT INTO xxl_job.flink_job (name,status,cron,update_user,update_time,pre_schedule_time,next_schedule_time,create_time,dependency_conf,`statement`,create_user,avg_duration,priority,curr_time,resource_name) VALUES
	 ('ods_sdk_log','0','0 0/2 * * * ?',NULL,NULL,'1673161920','1673162040',NULL,'{"dependencys":[]}','create view tmp1 as(select *  from mysql_bi.xxl_job.xxl_job_log);
select * from tmp1;',NULL,0,0,'1673161920424','FlinkSqlGateway'),
	 ('ods_sdk_log2','0','0 0/2 * * * ?',NULL,NULL,'1673161920','1673162040',NULL,'        {"dependencys":[{"jobId":1,"dependentStartTimeRule":"-6mB","dependentEndRule":"-6mE"}]}','select *  from mysql_bi.xxl_job.xxl_job_log',NULL,0,0,'1673161920424','FlinkSqlGateway'),
	 ('ods_sdk_log','0','0 0/2 * * * ?',NULL,NULL,'1673161920','1673162040',NULL,'{"dependencys":[]}','create view tmp1 as(select *  from mysql_bi.xxl_job.xxl_job_log);
select * from tmp1;',NULL,0,0,'1673161920424','FlinkSqlGateway'),
	 ('ods_sdk_log2','0','0 0/2 * * * ?',NULL,NULL,'1673161920','1673162040',NULL,'        {"dependencys":[{"jobId":1,"dependentStartTimeRule":"-6mB","dependentEndRule":"-6mE"}]}','select *  from mysql_bi.xxl_job.xxl_job_log',NULL,0,0,'1673161920424','FlinkSqlGateway'),
	 ('ods_sdk_log','0','0 0/2 * * * ?',NULL,NULL,'1673161920','1673162040',NULL,'{"dependencys":[]}','create view tmp1 as(select *  from mysql_bi.xxl_job.xxl_job_log);
select * from tmp1;',NULL,0,0,'1673161920424','FlinkSqlGateway'),
	 ('ods_sdk_log2','0','0 0/2 * * * ?',NULL,NULL,'1673161920','1673162040',NULL,'        {"dependencys":[{"jobId":1,"dependentStartTimeRule":"-6mB","dependentEndRule":"-6mE"}]}','select *  from mysql_bi.xxl_job.xxl_job_log',NULL,0,0,'1673161920424','FlinkSqlGateway');


-- xxl_job.flink_job definition


 drop table  if exists xxl_job.`flink_job_task_log`;
 CREATE TABLE if not exists xxl_job.`flink_job_task_log`(
     `id`   int NOT NULL AUTO_INCREMENT COMMENT '自增主键',
     `job_task_code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一任务执行记录编码',
     `msg` text COLLATE utf8mb4_general_ci default NULL COMMENT '任务执行记录日志',
     PRIMARY KEY (`id`) USING BTREE
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='调度任务执行日志表'
;

drop table  if exists xxl_job.`flink_job_task`;
 CREATE TABLE if not exists xxl_job.`flink_job_task` (
       `id` int NOT NULL AUTO_INCREMENT COMMENT '自增主键',
       `job_id` int DEFAULT NULL COMMENT 'job_id',
       `code` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一任务执行记录编码',
       `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '作业名',
       `status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '实例状态',
       `schedule_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '调度时间',
       `commit_user` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '提交者',
       `update_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '更新时间',
       `start_time` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '开始执行时间',
       `resource_name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '執行引擎名称',
       `priority` int DEFAULT 0 COMMENT '执行优先级',
       `action` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
       `curr_time` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,

       PRIMARY KEY (`id`) USING BTREE
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='调度任务执行表'
;

 DROP TABLE IF EXISTS `flink_database`;
 CREATE TABLE `flink_database` (
                                   `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
                                   `tenant_id` int NOT NULL DEFAULT '1' COMMENT 'tenant id',
                                   `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'database name',
                                   `alias` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'database alias',
                                   `group_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Default' COMMENT 'database belong group name',
                                   `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'database type',
                                   `driver_class` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'database driverClass',
                                   `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'database ip',
                                   `port` int DEFAULT NULL COMMENT 'database port',
                                   `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'database url',
                                   `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'username',
                                   `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'password',
                                   `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'note',
                                   `flink_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'Flink configuration',
                                   `flink_template` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'Flink template',
                                   `db_version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'version，such as: 11g of oracle ，2.2.3 of hbase',
                                   `status` tinyint(1) DEFAULT NULL COMMENT 'heartbeat status',
                                   `health_time` datetime DEFAULT NULL COMMENT 'last heartbeat time of trigger',
                                   `heartbeat_time` datetime DEFAULT NULL COMMENT 'last heartbeat time',
                                   `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'is enable',
                                   `create_time` datetime DEFAULT NULL COMMENT 'create time',
                                   `update_time` datetime DEFAULT NULL COMMENT 'update time',
                                   PRIMARY KEY (`id`) USING BTREE,
                                   UNIQUE KEY `dlink_database_un` (`name`,`tenant_id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='database management';

INSERT INTO xxl_job.flink_database (tenant_id,name,alias,group_name,`type`,driver_class,ip,port,url,username,password,note,flink_config,flink_template,db_version,status,health_time,heartbeat_time,enabled,create_time,update_time) VALUES
	 (1,'mysql_bi','mysql_bi','Default','MYSQL','com.mysql.cj.jdbc.Driver',NULL,NULL,'jdbc:mysql://localhost:3306/xxl_job?&allowMultiQueries=true&characterEncoding=utf-8','root','123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL);
