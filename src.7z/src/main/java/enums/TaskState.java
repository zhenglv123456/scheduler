package enums;

/**
 * @author 72716
 */

public enum TaskState {
    DEPENDENCY(0), DEPENDENTSUCCESS(1), RUNNING(2),FAILED(3),SUCCESS(4);
    private int code;

    TaskState(int code) {
        this.code = code;
    }

    public static TaskState getState(int code) {
        for (TaskState taskState : TaskState.values()) {
            if (taskState.code == code) {
                return taskState;
            }
        }
        throw new IllegalArgumentException("unsupported job cycle " + code);
    }

    public String getCode() {
        return String.valueOf(code);
    }

    public static void main(String[] args) {
        System.out.println(TaskState.SUCCESS.getCode());
    }
}
