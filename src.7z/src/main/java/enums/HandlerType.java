package enums;

public enum HandlerType {
    CheckRunningTaskStatusHandler("CheckRunningTaskStatusHandler"),
    DependencyCheckHandler("DependencyCheckHandler"),
    ExecuteSuccessDependencyJobTaskHandler("ExecuteSuccessDependencyJobTaskHandler"),
    ScanDelayJobsAndGenTasksHandler("ScanDelayJobsAndGenTasksHandler"),
    ScanJobsAndGenTasksHandler("ScanJobsAndGenTasksHandler");
    private String code;

    HandlerType(String code) {
        this.code = code;
    }

    public static HandlerType getState(String code) {
        for (HandlerType handlerType : HandlerType.values()) {
            if (handlerType.code == code) {
                return handlerType;
            }
        }
        throw new IllegalArgumentException("unsupported job cycle " + code);
    }

    public String getCode() {
        return code;
    }
}
