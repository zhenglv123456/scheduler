package enums;

/**
 * @author 72716
 */

public enum TaskAction {
    // 正常调度任务 0；重跑任务 1
    NORMAL(0), RERUN(1),DELAY(2),GENERATEBYFAILED(3);
    private int code;

    TaskAction(int code) {
        this.code = code;
    }

    public static TaskAction getAction(int code) {
        for (TaskAction taskState : TaskAction.values()) {
            if (taskState.code == code) {
                return taskState;
            }
        }
        throw new IllegalArgumentException("unsupported : " + code);
    }

    public String getCode() {
        return String.valueOf(code);
    }

}
