package enums;

public enum DateCalRule {
    // s,m,mE,mB,H,HB,HE,d,dB,dE,w,wB,wE,M,MB,ME
    s(1),m(2),mE(3),mB(4),H(5),HB(6),HE(7),d(8),
    dB(9),dE(10),w(11),wB(12),wE(13),M(14),MB(15),ME(16);
    private int code;

    DateCalRule(int code) {
        this.code = code;
    }

    public static DateCalRule getCalRuleEnum(String calRule){

        if("s".equals(calRule)){
            return s;
        }else if ("ME".equals(calRule)){
            return ME;
        }else if ("M".equals(calRule)){
            return M;
        }else if ("MB".equals(calRule)){
            return MB;
        }else if ("wB".equals(calRule)){
            return wB;
        }else if ("wE".equals(calRule)){
            return wE;
        }else if ("mB".equals(calRule)){
            return mB;
        }else if ("H".equals(calRule)){
            return H;
        }else if ("HB".equals(calRule)){
            return HB;
        }else if ("HE".equals(calRule)){
            return HE;
        }else if ("d".equals(calRule)){
            return d;
        }else if ("dB".equals(calRule)){
            return dB;
        }else if ("dE".equals(calRule)){
            return dE;
        }else if ("w".equals(calRule)){
            return w;
        }else if ("m".equals(calRule)){
            return m;
        }else if ("mE".equals(calRule)){
            return mE;
        }else {
            return null;
        }


    }

}
