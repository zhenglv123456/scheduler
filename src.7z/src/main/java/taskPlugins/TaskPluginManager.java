package taskPlugins;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static java.lang.String.format;

public class TaskPluginManager {
    private final Map<String, TaskChannel> taskChannelMap = new ConcurrentHashMap<>();

    public Map<String, TaskChannel> getTaskChannelMap() {
        return Collections.unmodifiableMap(taskChannelMap);
    }

    private void loadTaskChannel(TaskChannelFactory taskChannelFactory) {
        TaskChannel taskChannel = taskChannelFactory.create();
        taskChannelMap.put(taskChannelFactory.getName(), taskChannel);
    }


    public void installPlugin() {
        final Set<String> names = new HashSet<>();

        ServiceLoader.load(TaskChannelFactory.class).forEach(factory -> {
            final String name = factory.getName();

//            logger.info("Registering task plugin: {}", name);
//
//            if (!names.add(name)) {
//                throw new TaskPluginException(format("Duplicate task plugins named '%s'", name));
//            }

            loadTaskChannel(factory);

//            logger.info("Registered task plugin: {}", name);

//            List<PluginParams> params = factory.getParams();
//            String paramsJson = PluginParamsTransfer.transferParamsToJson(params);
//
//            PluginDefine pluginDefine = new PluginDefine(name, PluginType.TASK.getDesc(), paramsJson);
//            int count = pluginDao.addOrUpdatePluginDefine(pluginDefine);
//            if (count <= 0) {
//                throw new TaskPluginException("Failed to update task plugin: " + name);
//            }
        });
    }
}
