package taskPlugins.flinkSqlGateway;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import conf.FlinkConf;
import meta.base.driver.Driver;
import meta.model.Column;
import meta.model.DataBase;
import meta.model.Table;
import model.FlinkDatabase;
import model.FlinkJob;
import model.FlinkJobTask;
import okhttp3.Response;
import taskPlugins.AbstractTask;
import utils.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

public class FlinkSqlGatewayTask extends AbstractTask {


    private FlinkJobTask flinkJobTask;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLUtil;

    public FlinkSqlGatewayTask(FlinkJobTask flinkJobTask, FlinkConf flinkConf, MySQLUtil mySQLUtil) {
        this.flinkJobTask=flinkJobTask;
        this.flinkConf = flinkConf;
        this.mySQLUtil = mySQLUtil;
    }

    /**
     * init task
     */
    @Override
    public void init() {

    }

    @Override
    public void handle() throws Exception {
        final int jobId = flinkJobTask.getJobId();
        final String mysqlJobTableName = flinkConf.getMysqlJobTableName();
        final List<FlinkJob> flinkJobs = mySQLUtil.queryList("select * from "+mysqlJobTableName+" where id ="+jobId, FlinkJob.class, true);


        final String sqlStatement = flinkJobs.get(0).getStatement();

        Stream<String> metaTableNames = getMetaTableNameFromSql(sqlStatement.replace("\n"," "));
        String url = flinkConf.getFlinkSqlGatewayUrl();
        String sessionHandleId = generateFlinkSqlGatewaySessions(url + "/v1/sessions");

        metaTableNames.forEach(metaTableName -> {
//            String databaseSourceConf = sourceService.getDatabaseSourceConf(metaTableName);
            FlinkDatabase flinkDatabase =  mySQLUtil.queryList("select * from flink_database where name= '"+metaTableName.split(RegexpUtils.SPLIT_POINT)[0].trim()+"'",FlinkDatabase.class,true).get(0);
            String flinkTableDDL = createFlinkTableDDL(metaTableName, metaTableName, flinkDatabase, metaTableName.split(RegexpUtils.SPLIT_POINT)[1].trim());
            String DDLStatement = "{\"" + RegexpUtils.STATEMENT + "\":\"" + flinkTableDDL.replace("\n", " ") + "\"}";
            exceuteDDL(url + "/v1/sessions/" + sessionHandleId + "/statements/", DDLStatement);
            System.out.println(DDLStatement);

        });

        String QueryStatement = "{\"" + RegexpUtils.STATEMENT + "\":\"" + tranformQuerySql(sqlStatement.replace("\n"," " )) + "\"}";
        System.out.println(QueryStatement);

        Dataframe resultData = executeQuery(url, sessionHandleId, QueryStatement);


    }

    private Dataframe executeQuery(String url, String sessionHandleId, String queryStatement) {
//        String resulte = "";
        final Dataframe dataframe = new Dataframe();
        try {
            final String s = OkHttpClientUtil.getInstance().postJson(url + "/v1/sessions/" + sessionHandleId + "/statements/", queryStatement);
//            System.out.println(s);//{"operationHandle":"8a0364d4-e77d-4263-9258-76f03be41584"}

            final Response response =
                    OkHttpClientUtil.getInstance().getData(url + "/v1/sessions/" + sessionHandleId + "/operations/" + JSON.parseObject(s).getString("operationHandle") + "/result/0");

            System.out.println(response);
            final String responseBody = response.body().string();
            final HashMap<String, String> resultMAP = new HashMap<>();

            fetchData(url, resultMAP, responseBody,dataframe);

//            final Collection<Object> values = resultMAP.values();
//            System.out.println(values.toString());
            final List<List<Object>> lists = new ArrayList<>();
            resultMAP.values().forEach(one -> {
                System.out.println(one.replace("[","").replace("]",""));
                final ArrayList<Object> objects = new ArrayList<>();
                objects.addAll(Arrays.asList(one.replace("[","").replace("]","").split(",")));
                lists.add(objects);
            });
//{"data":
// {"columns":[{"fmt":null,"foreignKeys":null,"name":["id"],"type":"NUMERIC"},
// {"fmt":null,"foreignKeys":null,"name":["job_group"],"type":"STRING"},
// {"fmt":null,"foreignKeys":null,"name":["job_id"],"type":"STRING"},,{"fmt":null,"foreignKeys":null,"name":["executor_handler"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["executor_param"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["executor_sharding_param"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["executor_fail_retry_count"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["trigger_time"],"type":"DATE"},{"fmt":null,"foreignKeys":null,"name":["trigger_code"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["trigger_msg"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["handle_time"],"type":"DATE"},{"fmt":null,"foreignKeys":null,"name":["handle_code"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["handle_msg"],"type":"STRING"},{"fmt":null,"foreignKeys":null,"name":["alarm_status"],"type":"NUMERIC"}],
// "id":"DFcbabe00639a84efab62a12732ffd3da7","name":null,"pageInfo":null,
// "rows":[[1,1,1,null,null,null,null,0,"2022-07-24 08:50:00",200,null,null,100,null,2]],"script":"SELECT *  FROM  ( select * from xxl_job.xxl_job_log limit 1 )  AS `DATART_VTABLE`  LIMIT 1000  OFFSET 0","vizId":null,"vizType":null},"errCode":0,"exception":null,"message":null,"pageInfo":null,"success":true,"warnings":null}
            dataframe.setRows(lists);
            dataframe.setScript(queryStatement);
            System.out.println(dataframe.toString());
            return dataframe;

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return dataframe;
    }

    private void fetchData(String url, HashMap<String, String> resultMAP, String response,Dataframe dataframe) throws IOException, InterruptedException {
        final JSONObject jsonObject = JSON.parseObject(response);
        if (jsonObject.containsKey("errors")) {
            final ArrayList<Column> columns = new ArrayList<>();
            final Column column = new Column();
            column.setName("errors");
            column.setType(ValueType.STRING);
            columns.add(column);
            dataframe.setColumns(columns);
//            return  jsonObject.getString("errors");
//            resultMAP.put("errors", StringUtils.replaceBlank(jsonObject.getString("errors").replace("\"","")));
            resultMAP.put("errors", "");
            return;
        }
//{"results":{"columns":[],"data":[]},"resultType":"NOT_READY","nextResultUri":
// "/v1/sessions/69e9dcb1-3348-4eed-a4d7-fc2d24140b86/operations/344f4c7d-7abf-47e0-ae85-5340e2a257a3/result/0"}
//        System.out.println(jsonObject);
        final JSONObject results = JSON.parseObject(jsonObject.getString("results"));
        final String resultType = jsonObject.getString("resultType");
        final String nextResultUri = jsonObject.getString("nextResultUri");

        if (resultType.equals("NOT_READY") || resultType.equals("PAYLOAD")) {
            final JSONArray data = JSON.parseArray(results.getString("data"));
            if (data.size() != 0) {
                data.forEach(single -> {
//                    System.out.println(single);
                    final JSONObject singleJsonObject = (JSONObject) single;
                    if (singleJsonObject.getString("kind").equals("INSERT")
                            || singleJsonObject.getString("kind").equals("UPDATE")
                            || singleJsonObject.getString("kind").equals("UPDATE_AFTER")) {
                        String key = singleJsonObject.getString("fields").toString();
                        String value = singleJsonObject.getString("fields");
                        resultMAP.put(key, value);

                    } else if (singleJsonObject.getString("kind").equals("UPDATE_BEFORE")) {
//                        System.out.println(singleJsonObject);
                        String key = singleJsonObject.getString("fields").toString();
                        resultMAP.remove(key);
                    }


                });
            }
            Thread.sleep(10);
//            System.out.println(url + nextResultUri);
            final Response responseData = OkHttpClientUtil.getInstance().getData(url + nextResultUri);
            fetchData(url, resultMAP, responseData.body().string(),dataframe);
        }else{
            System.out.println(results);
            //{"data":[],"columns":[{"logicalType":{"nullable":false,"type":"INTEGER"},"name":"trigger_code"},
            // {"logicalType":{"nullable":false,"type":"BIGINT"},"name":"pv"}]}
            final ArrayList<Column> columns = new ArrayList<>();

            final JSONArray flinkcolumns = (JSONArray) results.get("columns");
            flinkcolumns.forEach(oneFlinkColumn->{
                final JSONObject oneFlinkColumn1 = (JSONObject) oneFlinkColumn;
                final Column column = new Column();
                column.setName(oneFlinkColumn1.getString("name"));
                final JSONObject logicalType = (JSONObject) oneFlinkColumn1.get("logicalType");
                final String type = (String) logicalType.get("type");
                if(type.equals("INTEGER")||type.equals("BIGINT")){
                    column.setType(ValueType.NUMERIC);
                }else  if(type.equals("VARCHAR")||type.equals("STRING")){
                    column.setType(ValueType.STRING);
                }
                columns.add(column);

            });

            dataframe.setColumns(columns);
        }

//        System.out.println(response);
    }


    public String createFlinkTableDDL(String tableName, String catalog, FlinkDatabase conf, String databasename) {
        System.out.println(tableName + catalog + conf + databasename);
        DataBase dataBase = null;
        try {
            dataBase = tranformDataBase(conf, tableName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Asserts.checkNotNull(dataBase, "该数据源不存在！");
        Driver driver = Driver.build(dataBase.getDriverConfig());
        List<Column> columns = driver.listColumns(databasename, tableName.split(RegexpUtils.SPLIT_POINT)[2].trim());
        dataBase.setFlinkConnectorType(driver.getFlinkConnectorType());
        System.out.println(columns);
        Table table = Table.build(tableName, databasename, columns);
        return table.getFlinkTableSql(dataBase.getName(), dataBase);
    }

    private void exceuteDDL(String url, String ddlStatement) {
        try {
//            System.out.println(url + ddlStatement);
            OkHttpClientUtil.getInstance().postJson(url, ddlStatement);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private DataBase tranformDataBase(FlinkDatabase conf, String name) throws Exception {
        //{"enableSpecialSQL":false,
        // "password":"_encrypted_8SXo8VjsdCL5CAtPGxqKHw==",
        // "serverAggregate":false,"syncInterval":"60",
        // "driverClass":"com.mysql.cj.jdbc.Driver","dbType":"MYSQL",
        // "enableSyncSchemas":true,"user":"root",
        // "url":"jdbc:mysql://localhost:3306","properties":{}}
        final DataBase dataBase = new DataBase();
//        final JSONObject databaseJsonConf = JSON.parseObject(conf);
        dataBase.setName(name);
        dataBase.setUrl(conf.getUrl());
        dataBase.setPassword(conf.getPassword());
//        dataBase.setPassword(AESUtil.decrypt(databaseJsonConf.getString("password").split("_encrypted_")[1]));
        dataBase.setType(conf.getType());
        dataBase.setUsername(conf.getUsername());
        dataBase.setDriverClass(conf.getDriverClass());


        return dataBase;
    }

    private String tranformQuerySql(String sql) {
        final StringBuilder stringBuilder = new StringBuilder();
        Arrays.stream(sql.replace(")", " )").split(" ")).forEach(one -> {
            if (one.matches(RegexpUtils.REGEXP_TWOPOINT)) {
                stringBuilder.append(" `" + one + "` ");
            } else {
                stringBuilder.append(" " + one + " ");
            }
        });
        return stringBuilder.toString();
    }

    private Stream<String> getMetaTableNameFromSql(String sql) {

        final Stream<String> stringStream = Arrays.stream(sql.replace(")", " ").split(" ")).filter(single -> {
            return single.matches(RegexpUtils.REGEXP_TWOPOINT);
        });


        return stringStream;
    }

    private String generateFlinkSqlGatewaySessions(String url) {
        //{"sessionHandle":"63c9f5d1-caec-4b44-9893-cf7af3cd8f92"}
        String s = "";
        try {
            s = JSON.parseObject(OkHttpClientUtil.getInstance().postJson(url, "")).getString("sessionHandle");
            System.out.println(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return s;
    }
}
