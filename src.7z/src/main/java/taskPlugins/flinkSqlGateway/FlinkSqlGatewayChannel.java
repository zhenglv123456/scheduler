package taskPlugins.flinkSqlGateway;

import conf.FlinkConf;
import model.FlinkJobTask;
import taskPlugins.AbstractTask;
import taskPlugins.TaskChannel;
import utils.MySQLUtil;

public class FlinkSqlGatewayChannel  implements TaskChannel {
    @Override
    public AbstractTask createTask(FlinkJobTask flinkJobTask, FlinkConf flinkConf, MySQLUtil mySQLUtil) {
        return new FlinkSqlGatewayTask(flinkJobTask,flinkConf,mySQLUtil);
    }
}
