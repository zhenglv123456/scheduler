package taskPlugins.flinkSqlGateway;

import taskPlugins.TaskChannel;
import taskPlugins.TaskChannelFactory;

public class FlinkSqlGatewayChannelFactory implements TaskChannelFactory {
    @Override
    public String getName() {
        return "FlinkSqlGateway";
    }

    @Override
    public TaskChannel create() {
        return new FlinkSqlGatewayChannel();
    }
}
