package taskPlugins;

public interface TaskChannelFactory extends UiChannelFactory {

    TaskChannel create();
}
