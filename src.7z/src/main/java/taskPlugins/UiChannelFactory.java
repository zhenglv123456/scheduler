package taskPlugins;

public interface UiChannelFactory {
    String getName();
}
