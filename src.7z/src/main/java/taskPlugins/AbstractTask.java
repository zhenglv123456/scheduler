package taskPlugins;

public abstract class AbstractTask {

    /**
     * init task
     */
    public void init() {
    }

    public abstract String handle() throws Exception;
}
