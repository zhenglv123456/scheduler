package taskPlugins;

import model.FlinkJobTask;

public abstract class AbstractTask {

    /**
     * init task
     */
    public void init() {
    }

    public abstract void handle() throws Exception;
}
