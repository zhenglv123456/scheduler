package taskPlugins;

import conf.FlinkConf;
import model.FlinkJobTask;
import utils.MySQLUtil;

public interface TaskChannel {
    AbstractTask createTask(FlinkJobTask flinkJobTask, FlinkConf flinkConf, MySQLUtil mySQLUtil);
}
