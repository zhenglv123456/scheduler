package connector;

/**
 * @author 72716
 */
public interface Connector {


}
