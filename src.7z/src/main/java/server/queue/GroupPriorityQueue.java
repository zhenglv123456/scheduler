package server.queue;

import jobDealer.JobDealer;
import jobDealer.JobSubmitDealer;
import model.FlinkJobTask;
import server.comparator.JobClientComparator;
import threadfactory.CustomThreadFactory;

import java.util.concurrent.*;

public class GroupPriorityQueue {


    private String jobResource;
    private JobDealer jobDealer;

    private int queueSizeLimited=500;

    private PriorityBlockingQueue<FlinkJobTask> queue = null;
    private JobSubmitDealer jobSubmitDealer = null;

    public String getJobResource() {
        return jobResource;
    }

    public JobDealer getJobDealer() {
        return jobDealer;
    }

    public PriorityBlockingQueue<FlinkJobTask> getQueue() {
        return queue;
    }

    public static GroupPriorityQueue builder() {
        return new GroupPriorityQueue();
    }

    public GroupPriorityQueue setJobResource(String jobResource) {
        this.jobResource = jobResource;
        return this;
    }

    public GroupPriorityQueue setJobDealer(JobDealer jobDealer) {
        this.jobDealer = jobDealer;
        return this;
    }


    /**
     * 每个GroupPriorityQueue中增加独立线程，以定时调度方式从数据库中获取任务。（数据库查询以id和优先级为条件）
     */
    public GroupPriorityQueue build() {
//        this.environmentContext = applicationContext.getBean(EnvironmentContext.class);
//        this.ScheduleJobCacheService = applicationContext.getBean(ScheduleJobCacheService.class);
//        this.jobPartitioner = applicationContext.getBean(JobPartitioner.class);
//        this.workerOperator = applicationContext.getBean(WorkerOperator.class);
//
//        this.queueSizeLimited = environmentContext.getQueueSize();
//
//        checkParams();

        this.queue = new PriorityBlockingQueue<>(queueSizeLimited * 2, new JobClientComparator());
        this.jobSubmitDealer = new JobSubmitDealer(this);

//        ScheduledExecutorService scheduledService = new ScheduledThreadPoolExecutor(1, new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_AcquireJob"));
//        scheduledService.scheduleWithFixedDelay(
//                new AcquireGroupQueueJob(),
//                WAIT_INTERVAL * 10L,
//                WAIT_INTERVAL,
//                TimeUnit.MILLISECONDS);

        ExecutorService jobSubmitService = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(), new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmit"));
        jobSubmitService.submit(jobSubmitDealer);
        return this;
    }

    public boolean add(FlinkJobTask jobClient, boolean judgeBlock, boolean insert) {
        return addRedirect(jobClient, insert);
    }


    private boolean addRedirect(FlinkJobTask jobClient, boolean insert) {
        if (queue.contains(jobClient)) {
//            LOGGER.info("jobId:{} unable add to queue, because jobId already exist.", jobClient.getJobId());
            return true;
        }

//        jobDealer.saveCache(jobClient, jobResource, EJobCacheStage.PRIORITY.getStage(), insert);

        queue.put(jobClient);
//        LOGGER.info("jobId:{} redirect add job to queue.", jobClient.getJobId());
        return true;
    }
}
