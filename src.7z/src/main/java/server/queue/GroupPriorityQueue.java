package server.queue;

import enums.HandlerType;
import handler.ScanDelayJobsAndGenTasksHandler;
import jobDealer.*;
import model.FlinkJob;
import model.FlinkJobTask;
import server.comparator.FlinkJobClientComparator;
import server.comparator.JobClientComparator;
import threadfactory.CustomThreadFactory;

import java.util.concurrent.*;

public class GroupPriorityQueue {


    private String jobResource;
    private JobDealer jobDealer;

    private boolean isQueueEmpty=true;

    private int queueSizeLimited=500;

    private PriorityBlockingQueue<FlinkJobTask> queue = null;

    private PriorityBlockingQueue<FlinkJobTask> checkRunningTaskStatusQueue = null;
    private PriorityBlockingQueue<FlinkJobTask> dependencyCheckJobQueue = null;

    private JobCheckRunningTaskStatusDealer jobCheckRunningTaskStatusDealer = null;
    private JobDependencyCheckJobDealer jobDependencyCheckJobDealer = null;

    private PriorityBlockingQueue<FlinkJob> scanDelayJobsAndGenTasksQueue = null;
    private PriorityBlockingQueue<FlinkJob> scanJobsAndGenTasksQueue = null;

    private ScanDelayJobsAndGenTasksDealer scanDelayJobsAndGenTasksDealer= null ;
    private ScanJobsAndGenTasksDealer scanJobsAndGenTasksDealer= null ;

    public PriorityBlockingQueue<FlinkJob> getScanJobsAndGenTasksQueue() {
        return scanJobsAndGenTasksQueue;
    }

    public void setScanJobsAndGenTasksQueue(PriorityBlockingQueue<FlinkJob> scanJobsAndGenTasksQueue) {
        this.scanJobsAndGenTasksQueue = scanJobsAndGenTasksQueue;
    }

    public ScanJobsAndGenTasksDealer getScanJobsAndGenTasksDealer() {
        return scanJobsAndGenTasksDealer;
    }

    public void setScanJobsAndGenTasksDealer(ScanJobsAndGenTasksDealer scanJobsAndGenTasksDealer) {
        this.scanJobsAndGenTasksDealer = scanJobsAndGenTasksDealer;
    }

    public boolean isQueueEmpty() {
        return isQueueEmpty;
    }

    public void setQueueEmpty(boolean queueEmpty) {
        isQueueEmpty = queueEmpty;
    }

    public PriorityBlockingQueue<FlinkJobTask> getCheckRunningTaskStatusQueue() {
        return checkRunningTaskStatusQueue;
    }

    public JobCheckRunningTaskStatusDealer getJobCheckRunningTaskStatusDealer() {
        return jobCheckRunningTaskStatusDealer;
    }

    public PriorityBlockingQueue<FlinkJob> getScanDelayJobsAndGenTasksQueue() {
        return scanDelayJobsAndGenTasksQueue;
    }

    public ScanDelayJobsAndGenTasksDealer getScanDelayJobsAndGenTasksDealer() {
        return scanDelayJobsAndGenTasksDealer;
    }

    public JobSubmitDealer getJobSubmitDealer() {
        return jobSubmitDealer;
    }

    private JobSubmitDealer jobSubmitDealer = null;

    public PriorityBlockingQueue<FlinkJobTask> getDependencyCheckJobQueue() {
        return dependencyCheckJobQueue;
    }

    public void setDependencyCheckJobQueue(PriorityBlockingQueue<FlinkJobTask> dependencyCheckJobQueue) {
        this.dependencyCheckJobQueue = dependencyCheckJobQueue;
    }

    public JobDependencyCheckJobDealer getJobDependencyCheckJobDealer() {
        return jobDependencyCheckJobDealer;
    }

    public void setJobDependencyCheckJobDealer(JobDependencyCheckJobDealer jobDependencyCheckJobDealer) {
        this.jobDependencyCheckJobDealer = jobDependencyCheckJobDealer;
    }

    public String getJobResource() {
        return jobResource;
    }

    public JobDealer getJobDealer() {
        return jobDealer;
    }

    public PriorityBlockingQueue<FlinkJobTask> getQueue() {
        return queue;
    }

    public static GroupPriorityQueue builder() {
        return new GroupPriorityQueue();
    }

    public GroupPriorityQueue setJobResource(String jobResource) {
        this.jobResource = jobResource;
        return this;
    }

    public GroupPriorityQueue setJobDealer(JobDealer jobDealer) {
        this.jobDealer = jobDealer;
        return this;
    }


    /**
     * 每个GroupPriorityQueue中增加独立线程，以定时调度方式从数据库中获取任务。（数据库查询以id和优先级为条件）
     */
    public GroupPriorityQueue build(String handlerType) {
        ExecutorService jobSubmitService = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(), new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmit"));

        HandlerType state = HandlerType.getState(handlerType);
        switch (state){
            case CheckRunningTaskStatusHandler:
                this.checkRunningTaskStatusQueue = new PriorityBlockingQueue<>(queueSizeLimited * 2, new JobClientComparator());
                this.jobCheckRunningTaskStatusDealer = new JobCheckRunningTaskStatusDealer(this);
                jobSubmitService.submit(jobCheckRunningTaskStatusDealer);
                break;
            case ExecuteSuccessDependencyJobTaskHandler:
                this.queue = new PriorityBlockingQueue<>(queueSizeLimited * 2, new JobClientComparator());
                this.jobSubmitDealer = new JobSubmitDealer(this);
                jobSubmitService.submit(jobSubmitDealer);
                break;
            case ScanDelayJobsAndGenTasksHandler:
               this.scanDelayJobsAndGenTasksQueue =
                       new PriorityBlockingQueue<>(queueSizeLimited * 2, new FlinkJobClientComparator());

                this.scanDelayJobsAndGenTasksDealer = new ScanDelayJobsAndGenTasksDealer(this);
                jobSubmitService.submit(scanDelayJobsAndGenTasksDealer);
                break;
            case DependencyCheckHandler:
                this.dependencyCheckJobQueue =  new PriorityBlockingQueue<>(queueSizeLimited * 2, new JobClientComparator());

                this.jobDependencyCheckJobDealer = new JobDependencyCheckJobDealer(this);
                jobSubmitService.submit(jobDependencyCheckJobDealer);
                break;
            case ScanJobsAndGenTasksHandler:
                this.scanJobsAndGenTasksQueue =  new PriorityBlockingQueue<>(queueSizeLimited * 2, new FlinkJobClientComparator());

                this.scanJobsAndGenTasksDealer = new ScanJobsAndGenTasksDealer(this);
                jobSubmitService.submit(scanJobsAndGenTasksDealer);

        }


        return this;
    }

    public boolean add(FlinkJobTask jobClient, boolean judgeBlock, boolean insert,String handlerType) {
        return addRedirect(jobClient, insert,handlerType);
    }


    private boolean addRedirect(FlinkJobTask jobClient, boolean insert,String handlerType) {

        HandlerType state = HandlerType.getState(handlerType);
        switch (state){
            case CheckRunningTaskStatusHandler:
                if (checkRunningTaskStatusQueue.contains(jobClient)) {
                    return true;
                }
                checkRunningTaskStatusQueue.put(jobClient);
                break;
            case ExecuteSuccessDependencyJobTaskHandler:
                if (queue.contains(jobClient)) {
                    return true;
                }
                queue.put(jobClient);
                break;
            case DependencyCheckHandler:
                if(dependencyCheckJobQueue.contains(jobClient)){
                    return true;
                }
                dependencyCheckJobQueue.put(jobClient);
                break;

        }

        return true;
    }
    public boolean addJob(FlinkJob flinkJob, boolean judgeBlock, boolean insert,String handlerType) {
        HandlerType state = HandlerType.getState(handlerType);
        switch (state) {
            case ScanDelayJobsAndGenTasksHandler:
                if (scanDelayJobsAndGenTasksQueue.contains(flinkJob)) {
                    return true;
                }
                scanDelayJobsAndGenTasksQueue.put(flinkJob);
                break;
            case ScanJobsAndGenTasksHandler:
                if(scanJobsAndGenTasksQueue.contains(flinkJob)){
                    return true;
                }
                scanJobsAndGenTasksQueue.put(flinkJob);
                break;

        }
        return true;
    }
}
