package server.comparator;

import model.FlinkJobTask;

import java.util.Comparator;

public class JobClientComparator implements Comparator<FlinkJobTask> {
    @Override
    public int compare(FlinkJobTask o1, FlinkJobTask o2) {
        return Long.compare(o1.getPriority(), o2.getPriority());
    }
}
