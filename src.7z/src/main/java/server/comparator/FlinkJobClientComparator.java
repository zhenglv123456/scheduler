package server.comparator;

import model.FlinkJob;
import model.FlinkJobTask;

import java.util.Comparator;

public class FlinkJobClientComparator implements Comparator<FlinkJob> {
    @Override
    public int compare(FlinkJob o1, FlinkJob o2) {
        return Long.compare(o1.getPriority(), o2.getPriority());
    }
}
