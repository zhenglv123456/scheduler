package model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FlinkJobDependency {
    private int jobId;
    private String dependentStartTimeRule;
    private String dependentEndRule;


    //        {"dependencys":[{"jobId":1,"dependentStartTimeRule":"-1dB","dependentEndRule":"-1dE"}]}


    public static List<FlinkJobDependency> tranform(String dependencyConf) {
        final ArrayList<FlinkJobDependency> objects = new ArrayList<>();
        final JSONObject jsonObject = JSON.parseObject(dependencyConf);
        final JSONArray dependencys = (JSONArray) jsonObject.get("dependencys");
        for (Object dependency : dependencys) {
            JSONObject dependencyJsonObject = (JSONObject) dependency;
            final FlinkJobDependency flinkJobDependency = new FlinkJobDependency();
            flinkJobDependency.setJobId((Integer) dependencyJsonObject.get("jobId"));
            flinkJobDependency.setDependentStartTimeRule((String) dependencyJsonObject.get("dependentStartTimeRule"));
            flinkJobDependency.setDependentEndRule((String) dependencyJsonObject.get("dependentEndRule"));
            objects.add(flinkJobDependency);


        }

        return objects;

    }

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    public String getDependentStartTimeRule() {
        return dependentStartTimeRule;
    }

    public void setDependentStartTimeRule(String dependentStartTimeRule) {
        this.dependentStartTimeRule = dependentStartTimeRule;
    }

    public String getDependentEndRule() {
        return dependentEndRule;
    }

    public void setDependentEndRule(String dependentEndRule) {
        this.dependentEndRule = dependentEndRule;
    }
}
