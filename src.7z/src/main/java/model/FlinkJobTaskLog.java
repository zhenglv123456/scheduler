package model;

public class FlinkJobTaskLog {
    private int id;
    private String jobTaskCode;
    private String msg;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJobTaskCode() {
        return jobTaskCode;
    }

    public void setJobTaskCode(String jobTaskCode) {
        this.jobTaskCode = jobTaskCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
