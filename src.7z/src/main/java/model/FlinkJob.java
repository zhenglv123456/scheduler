package model;

public class FlinkJob {

    private int id;
    private int avgDuration;
    private String name;
    private String status;
    private String cron;
    private String dependencyConf;
    private String createUser;
    private String createTime;
    private String updateUser;
    private String updateTime;
    private String preScheduleTime;
    private String nextScheduleTime;
    private String statement;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAvgDuration() {
        return avgDuration;
    }

    public void setAvgDuration(int avgDuration) {
        this.avgDuration = avgDuration;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCron() {
        return cron;
    }

    public void setCron(String cron) {
        this.cron = cron;
    }

    public String getDependencyConf() {
        return dependencyConf;
    }

    public void setDependencyConf(String dependencyConf) {
        this.dependencyConf = dependencyConf;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getPreScheduleTime() {
        return preScheduleTime;
    }

    public void setPreScheduleTime(String preScheduleTime) {
        this.preScheduleTime = preScheduleTime;
    }

    public String getNextScheduleTime() {
        return nextScheduleTime;
    }

    public void setNextScheduleTime(String nextScheduleTime) {
        this.nextScheduleTime = nextScheduleTime;
    }

    public String getStatement() {
        return statement;
    }

    public void setStatement(String statement) {
        this.statement = statement;
    }

    @Override
    public String toString() {
        return "FlinkJob{" +
                "id=" + id +
                ", avgDuration=" + avgDuration +
                ", name='" + name + '\'' +
                ", status='" + status + '\'' +
                ", cron='" + cron + '\'' +
                ", dependencyConf='" + dependencyConf + '\'' +
                ", createUser='" + createUser + '\'' +
                ", createTime='" + createTime + '\'' +
                ", updateUser='" + updateUser + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", preScheduleTime='" + preScheduleTime + '\'' +
                ", nextScheduleTime='" + nextScheduleTime + '\'' +
                ", statement='" + statement + '\'' +
                '}';
    }
}

