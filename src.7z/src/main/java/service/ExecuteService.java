package service;

import conf.FlinkConf;
import handler.*;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.types.Row;

public class ExecuteService implements Service {

    StreamExecutionEnvironment streamExecutionEnvironment;

    StreamTableEnvironment streamTableEnvironment;

    FlinkConf flinkConf;


    @Override
    public void start() {
        try {

            DataStream<Row> dataGenStream = DataGenSourceHandler.getSourceTable(streamTableEnvironment, flinkConf);
            processHandlers(dataGenStream);

            streamExecutionEnvironment.execute(flinkConf.getFlinkJobName());


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void processHandlers(DataStream<Row> dataGenStream) {
        processScanJobsAndGenTasksHandler(dataGenStream);
        processScanDelayJobsAndGenTasksHandler(dataGenStream);

        processDependencyCheckHandler(dataGenStream);

        processExecuteSuccessDependencyJobTaskHandler(dataGenStream);

        processCheckRunningTaskStatusHandler(dataGenStream);
    }

    private void processCheckRunningTaskStatusHandler(DataStream<Row> dataGenStream) {
        for (int i = 0; i < flinkConf.getCheckRunningTaskStatusHandlerCounts(); i++) {
            dataGenStream.process(new CheckRunningTaskStatusHandler(i,flinkConf));
        }
    }

    private void processExecuteSuccessDependencyJobTaskHandler(DataStream<Row> dataGenStream) {
        for (int i = 0; i < flinkConf.getExecuteSuccessDependencyJobTaskHandlerCounts(); i++) {
            dataGenStream.process(new ExecuteSuccessDependencyJobTaskHandler(i,flinkConf));
        }

    }

    private void processScanDelayJobsAndGenTasksHandler(DataStream<Row> dataGenStream) {
        for (int i = 0; i < flinkConf.getScanDelayJobsAndGenTasksHandlerCounts(); i++) {
            dataGenStream.process(new ScanDelayJobsAndGenTasksHandler(i, flinkConf));
        }
    }

    private void processDependencyCheckHandler(DataStream<Row> dataGenStream) {
        for (int i = 0; i < flinkConf.getDependencyCheckHandlerCounts(); i++) {
            dataGenStream.process(new DependencyCheckHandler(i, flinkConf));
        }
    }

    private void processScanJobsAndGenTasksHandler(DataStream<Row> dataGenStream) {
        for (int i = 0; i < flinkConf.getScanJobsAndGenTasksHandlerCounts(); i++) {
            dataGenStream.process(new ScanJobsAndGenTasksHandler(i, flinkConf));
        }
    }

    @Override
    public void init() {
        flinkConf = new FlinkConf();
        flinkConf.init();
        streamExecutionEnvironment = StreamExecutionEnvironment.createLocalEnvironment(flinkConf.getConfiguration());
        streamExecutionEnvironment.setParallelism(flinkConf.getSetParallelism());
        if (flinkConf.isDisableOperatorChaining()) {
            streamExecutionEnvironment.disableOperatorChaining();
        }
        streamTableEnvironment = StreamTableEnvironment.create(streamExecutionEnvironment, EnvironmentSettings.newInstance().build());

    }

}
