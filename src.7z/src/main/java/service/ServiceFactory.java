package service;

public class ServiceFactory {

    public static Service getInstance(Class clz){
         Service service = null;
        try {
            service = (Service) clz.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return service;
    }
}
