package service;

public interface Service {
    public void start();
    public void init();
}
