package handler;

import conf.FlinkConf;
import jobDealer.JobDealer;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import utils.MySQLUtil;

public class CheckRunningTaskStatusHandler extends ProcessFunction<Row, Row> {
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    public CheckRunningTaskStatusHandler(FlinkConf flinkConf) {
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

    }
    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        
    }
}
