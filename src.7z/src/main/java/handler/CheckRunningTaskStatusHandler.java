package handler;

import conf.FlinkConf;
import jobDealer.JobDealer;
import model.FlinkJobTask;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import utils.FlinkStatusUtil;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

public class CheckRunningTaskStatusHandler extends ProcessFunction<Row, Row> {
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    public CheckRunningTaskStatusHandler(FlinkConf flinkConf) {
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

    }
    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {

        final List<FlinkJobTask> flinkJobTasks
                = mySQLJobUtil.queryList("select * from "+flinkConf.getMysqlJobTaskTableName()+" where status='2' order by start_time asc limit 300", FlinkJobTask.class, true);
        flinkJobTasks.forEach(flinkJobTask -> {
            try {
                final String jobID = FlinkStatusUtil.getJobID(flinkConf.getFlinkJobsUrl(),flinkJobTask.getCode());
                if(StringUtils.isBlank(jobID)){
                    // 没有查到jobid
                    return;
                }
                final String jobState = FlinkStatusUtil.getJobState(flinkConf.getFlinkJobsUrl(), jobID);
                System.out.println(jobState);
                //FAILED ,  FINISHED
                if("FINISHED".equals(jobState)){
                    // 如果查询到任务执行完成，更新状态为4 ，
                    flinkJobTask.setStatus("4");
                }else if("FAILED".equals(jobState)){
                    // 如果查询到任务执行错误，更新状态为3
                    flinkJobTask.setStatus("3");
                }
                flinkJobTask.setUpdateTime(String.valueOf(TimeUtil.localDateTimeToMilliSecond(LocalDateTime.now())));
                final HashMap<String, Object> objectObjectHashMap = new HashMap<>();
                objectObjectHashMap.put("id", flinkJobTask.getId());
                objectObjectHashMap.put("code", flinkJobTask.getCode());
                mySQLJobUtil.upsert(flinkConf.getMysqlJobTaskTableName(),true,flinkJobTask,objectObjectHashMap);


            } catch (IOException e) {
                e.printStackTrace();
            }


        });


    }
}
