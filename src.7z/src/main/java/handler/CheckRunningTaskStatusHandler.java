package handler;

import conf.FlinkConf;
import enums.HandlerType;
import enums.TaskState;
import jobDealer.JobDealer;
import model.FlinkJobTask;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import server.queue.GroupPriorityQueue;
import utils.FlinkStatusUtil;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;

public class CheckRunningTaskStatusHandler extends ProcessFunction<Row, Row> {
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    private int slice;
    private JobDealer jobDealer;
    public CheckRunningTaskStatusHandler(int slice,FlinkConf flinkConf) {

        this.slice = slice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());
        jobDealer = new JobDealer(flinkConf,mySQLJobUtil);

    }
    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {

        Map<String, GroupPriorityQueue> priorityQueueMap = jobDealer.getPriorityQueueMap();


        if(priorityQueueMap.size()==0){
            final List<FlinkJobTask> flinkJobTasks
                    = mySQLJobUtil.queryList("select * from "
                            +flinkConf.getMysqlJobTaskTableName()+" where status= '"
                            +TaskState.RUNNING.getCode()+"' order by start_time asc limit 300",
                    FlinkJobTask.class, true);
            flinkJobTasks.forEach(flinkJobTask -> {
                if((flinkJobTask.getJobId()-slice)% flinkConf.getCheckRunningTaskStatusHandlerCounts()==0) {

                    GroupPriorityQueue groupPriorityQueue = jobDealer.getPriorityQueueMap().get(flinkJobTask.getResourceName());
                    if (groupPriorityQueue != null) {
                        groupPriorityQueue.setQueueEmpty(false);
                    }

                    jobDealer.addCheckRunningTaskStatusJob(flinkJobTask, HandlerType.CheckRunningTaskStatusHandler.getCode());


                }
            });
        }else {
            priorityQueueMap.values().forEach(o->{
                String jobResource = o.getJobResource();
                PriorityBlockingQueue<FlinkJobTask> checkRunningTaskStatusQueue = o.getCheckRunningTaskStatusQueue();
                boolean queueEmpty = o.isQueueEmpty();
                if(queueEmpty){
                    final List<FlinkJobTask> flinkJobTasks
                            = mySQLJobUtil.queryList("select * from "
                                    +flinkConf.getMysqlJobTaskTableName()+" where status= '"
                                    +TaskState.RUNNING.getCode()+"' and resource_name = '"+jobResource
                                    +"' order by start_time asc limit 300",
                            FlinkJobTask.class, true);
                    flinkJobTasks.forEach(flinkJobTask -> {
                        if((flinkJobTask.getJobId()-slice)% flinkConf.getCheckRunningTaskStatusHandlerCounts()==0) {

                            o.setQueueEmpty(false);
                            jobDealer.addCheckRunningTaskStatusJob(flinkJobTask, HandlerType.CheckRunningTaskStatusHandler.getCode());
                        }
                    });
                }
            });
        }

    }
}
