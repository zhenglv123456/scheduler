package handler;

import conf.FlinkConf;
import jobDealer.JobDealer;
import model.FlinkJobTask;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import utils.FlinkStatusUtil;
import utils.MySQLUtil;

import java.io.IOException;
import java.util.List;

public class CheckRunningTaskStatusHandler extends ProcessFunction<Row, Row> {
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    public CheckRunningTaskStatusHandler(FlinkConf flinkConf) {
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

    }
    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {

        final List<FlinkJobTask> flinkJobTasks
                = mySQLJobUtil.queryList("select * from "+flinkConf.getMysqlJobTaskTableName()+" where status='2' limit 300", FlinkJobTask.class, true);

        System.out.println(flinkJobTasks);
        flinkJobTasks.forEach(flinkJobTask -> {
            try {
                final String jobID = FlinkStatusUtil.getJobID(flinkConf.getFlinkJobsUrl(),flinkJobTask.getCode());
                if(StringUtils.isBlank(jobID)){
                    // 没有查到jobid
                    return;
                }
                final String jobState = FlinkStatusUtil.getJobState(flinkConf.getFlinkJobsUrl(), jobID);
                System.out.println(jobState);
            } catch (IOException e) {
                e.printStackTrace();
            }


        });


    }
}
