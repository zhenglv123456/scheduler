package handler;

import conf.FlinkConf;
import conf.JobTaskConf;
import jobDealer.JobDealer;
import model.FlinkJobTask;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import utils.MySQLUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 72716
 */
public class ExecuteSuccessDependencyJobTaskHandler extends ProcessFunction<Row, Row>  {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    private  JobDealer jobDealer;


    public ExecuteSuccessDependencyJobTaskHandler(int i, FlinkConf flinkConf) {
        this.slice = slice;
        this.flinkConf = flinkConf;
    }
    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

        jobDealer=new JobDealer(flinkConf,mySQLJobUtil);
        jobDealer.init();
    }


    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime ldt = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());

        List<FlinkJobTask> waitToExecuteFlinkJobTasks = scanWaitToExecuteFlinkJobTask(slice, flinkConf.getExecuteSuccessDependencyJobTaskHandlerCounts(), flinkConf.getMysqlJobTaskTableName());

        for (FlinkJobTask dependencyFlinkJobTask : waitToExecuteFlinkJobTasks) {
            ExecuteFlinkJobTasks(dependencyFlinkJobTask, ldt);
        }



    }

    private void ExecuteFlinkJobTasks(FlinkJobTask dependencyFlinkJobTask, LocalDateTime ldt) {
        // todo
        jobDealer.addSubmitJob(dependencyFlinkJobTask);

    }

    private List<FlinkJobTask> scanWaitToExecuteFlinkJobTask(int slice, int executeSuccessDependencyJobTaskHandlerCounts, String mysqlJobTaskTableName) {
        String scanWaitToExecuteFlinkJobTaskSql = JobTaskConf.generateScanWaitToExecuteFlinkJobTaskSql(mysqlJobTaskTableName);
        final List<FlinkJobTask> flinkJobTasks = mySQLJobUtil.queryList(scanWaitToExecuteFlinkJobTaskSql, FlinkJobTask.class, true);
        int start = flinkJobTasks.size() / executeSuccessDependencyJobTaskHandlerCounts * slice;
        int end = flinkJobTasks.size() / executeSuccessDependencyJobTaskHandlerCounts * (slice + 1);
        final ArrayList<FlinkJobTask> flinkJobTasks1 = new ArrayList<>();

        for (int i = 0; i < flinkJobTasks.size(); i++) {
            if (slice == executeSuccessDependencyJobTaskHandlerCounts - 1) {
                if (i >= start) {
                    flinkJobTasks1.add(flinkJobTasks.get(i));

                }
            } else {
                if (i >= start && i < end) {

                    flinkJobTasks1.add(flinkJobTasks.get(i));
                }
            }
        }

        return flinkJobTasks1;


    }
}
