package handler;

import conf.FlinkConf;
import conf.JobTaskConf;
import enums.HandlerType;
import enums.TaskState;
import jobDealer.JobDealer;
import model.FlinkJobTask;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import server.queue.GroupPriorityQueue;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.logging.Handler;

/**
 * @author 72716
 */
public class ExecuteSuccessDependencyJobTaskHandler extends ProcessFunction<Row, Row>  {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    private  JobDealer jobDealer;


    public ExecuteSuccessDependencyJobTaskHandler(int slice, FlinkConf flinkConf) {
        this.slice = slice;
        this.flinkConf = flinkConf;
    }
    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

        jobDealer=new JobDealer(flinkConf,mySQLJobUtil);
        jobDealer.init();
    }


    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime ldt = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());
        Map<String, GroupPriorityQueue> priorityQueueMap = jobDealer.getPriorityQueueMap();

        if(priorityQueueMap.size()==0){
            // 只扫描不是重跑的任务
            List<FlinkJobTask> waitToExecuteFlinkJobTasks = scanWaitToExecuteFlinkJobTask(
                    slice, flinkConf.getExecuteSuccessDependencyJobTaskHandlerCounts(),
                    flinkConf.getMysqlJobTaskTableName(),null);

            for (FlinkJobTask dependencyFlinkJobTask : waitToExecuteFlinkJobTasks) {
                GroupPriorityQueue groupPriorityQueue = jobDealer.getPriorityQueueMap().get(dependencyFlinkJobTask.getResourceName());
                if (groupPriorityQueue != null) {
                    groupPriorityQueue.setQueueEmpty(false);
                }
                    ExecuteFlinkJobTasks(dependencyFlinkJobTask, ldt);


            }

        }else {
            priorityQueueMap.values().forEach(o->{
                String jobResource = o.getJobResource();
                boolean queueEmpty = o.isQueueEmpty();
                if(queueEmpty){
                    // 只扫描不是重跑的任务
                    List<FlinkJobTask> waitToExecuteFlinkJobTasks = scanWaitToExecuteFlinkJobTask(
                            slice, flinkConf.getExecuteSuccessDependencyJobTaskHandlerCounts(),
                            flinkConf.getMysqlJobTaskTableName(),jobResource);

                    for (FlinkJobTask dependencyFlinkJobTask : waitToExecuteFlinkJobTasks) {
//                        if((dependencyFlinkJobTask.getJobId()-slice)% flinkConf.getExecuteSuccessDependencyJobTaskHandlerCounts()==0) {
                            o.setQueueEmpty(false);
                            ExecuteFlinkJobTasks(dependencyFlinkJobTask, ldt);
//                        }
                    }
                }
            });

        }





    }

    private void ExecuteFlinkJobTasks(FlinkJobTask dependencyFlinkJobTask, LocalDateTime ldt) {
        jobDealer.addSubmitJob(dependencyFlinkJobTask,HandlerType.ExecuteSuccessDependencyJobTaskHandler.getCode());

    }

    private List<FlinkJobTask> scanWaitToExecuteFlinkJobTask(int slice, int executeSuccessDependencyJobTaskHandlerCounts, String mysqlJobTaskTableName,String jobResource) {
        String scanWaitToExecuteFlinkJobTaskSql = JobTaskConf.generateScanWaitToExecuteFlinkJobTaskSql(mysqlJobTaskTableName,jobResource);
        final List<FlinkJobTask> flinkJobTasks = mySQLJobUtil.queryList(scanWaitToExecuteFlinkJobTaskSql, FlinkJobTask.class, true);
        final ArrayList<FlinkJobTask> flinkJobTasks1 = new ArrayList<>();

        for (int i = 0; i < flinkJobTasks.size(); i++) {
            if ((flinkJobTasks.get(i).getJobId() - slice) % flinkConf.getExecuteSuccessDependencyJobTaskHandlerCounts() == 0) {
                flinkJobTasks1.add(flinkJobTasks.get(i));

            }
        }

        return flinkJobTasks1;


    }
}
