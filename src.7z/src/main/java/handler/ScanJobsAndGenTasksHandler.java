package handler;

import conf.FlinkConf;
import conf.JobConf;
import model.FlinkJob;
import model.FlinkJobTask;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import org.apache.flink.util.StringUtils;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

public class ScanJobsAndGenTasksHandler extends ProcessFunction<Row, Row> {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;

    public ScanJobsAndGenTasksHandler(int slice, FlinkConf flinkConf) {
        this.slice = slice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

    }

    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime currtime = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());

        if (!StringUtils.isNullOrWhitespaceOnly(genScanCycleFlinkJobSqlFromMysql(currtime))) {
            final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(genScanCycleFlinkJobSqlFromMysql(currtime), FlinkJob.class, true);

            flinkJobs.forEach(flinkJob -> {
                System.out.println(flinkJob);

                final LocalDateTime currScheduleTime = CronUtils.scheduleTimeOf(flinkJob.getCron(),currtime);
                final LocalDateTime nextScheduleTime = CronUtils.nextScheduleTimeOf(flinkJob.getCron(),currtime);

                createFlinkJobTask(flinkJob,currScheduleTime);
                updateFlinkJobNextScheduleTime(flinkJob,currScheduleTime,nextScheduleTime);

            });
        }


    }

    private void updateFlinkJobNextScheduleTime(FlinkJob flinkJob, LocalDateTime currScheduleTime, LocalDateTime nextScheduleTime) {
        final HashMap<String, Object> stringObjectHashMap = new HashMap<>();
        stringObjectHashMap.put("id",flinkJob.getId());
//        stringObjectHashMap.put("nextScheduleTime",);
        flinkJob.setNextScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(nextScheduleTime)));
        flinkJob.setPreScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));

        mySQLJobUtil.update(flinkConf.getMysqlJobTableName(),true,flinkJob,stringObjectHashMap);
    }

    private void createFlinkJobTask(FlinkJob flinkJob, LocalDateTime currScheduleTime) {

        final FlinkJobTask flinkJobTask = new FlinkJobTask();
        flinkJobTask.setCode(RandomStringUtils.randomAlphanumeric(8)+flinkJob.getId()+String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));
        flinkJobTask.setScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));
        flinkJobTask.setJobId(flinkJob.getId());
        flinkJobTask.setStatus("0");
        mySQLJobUtil.insert(flinkConf.getMysqlJobTaskTableName(),true,flinkJobTask);
    }

    private String genScanCycleFlinkJobSqlFromMysql(LocalDateTime currLocalDateTime) {
        final long currTimeStamp = TimeUtil.localDateTimeToSeconds(currLocalDateTime);
        long currTimeStampAdd = currTimeStamp + 60;
        if(currTimeStamp%60!=0){
            return "";
        }
        final String scanCycleFlinkJobSqlFromMysql
                = JobConf.getScanCycleFlinkJobSqlFromMysql(flinkConf.getMysqlJobTableName(), currTimeStamp, currTimeStampAdd);

        return scanCycleFlinkJobSqlFromMysql;

    }
}
