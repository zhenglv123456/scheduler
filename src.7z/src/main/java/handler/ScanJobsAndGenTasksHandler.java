package handler;

import conf.FlinkConf;
import conf.JobConf;
import enums.HandlerType;
import enums.TaskAction;
import jobDealer.JobDealer;
import model.FlinkJob;
import model.FlinkJobTask;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import org.apache.flink.util.StringUtils;
import server.queue.GroupPriorityQueue;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScanJobsAndGenTasksHandler extends ProcessFunction<Row, Row> {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    private JobDealer jobDealer;


    public ScanJobsAndGenTasksHandler(int slice, FlinkConf flinkConf) {
        this.slice = slice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());
        jobDealer = new JobDealer(flinkConf, mySQLJobUtil);

    }

    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime currtime = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());
        Map<String, GroupPriorityQueue> priorityQueueMap = jobDealer.getPriorityQueueMap();

        if (priorityQueueMap.size() == 0) {
            if (!StringUtils.isNullOrWhitespaceOnly(genScanCycleFlinkJobSqlFromMysql(currtime,null))) {
                final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(genScanCycleFlinkJobSqlFromMysql(currtime,null),
                        FlinkJob.class, true);

                flinkJobs.forEach(flinkJob -> {
                    if ((flinkJob.getId() - slice) % flinkConf.getScanJobsAndGenTasksHandlerCounts() == 0) {
                        GroupPriorityQueue groupPriorityQueue = jobDealer.getPriorityQueueMap().get(flinkJob.getResourceName());
                        if (groupPriorityQueue != null) {
                            groupPriorityQueue.setQueueEmpty(false);
                        }
                        flinkJob.setCurrTime(TimeUtil.localDateTimeToMilliSecond(currtime));
                        jobDealer.addScanJobsAndGenTasksJob(flinkJob, HandlerType.ScanJobsAndGenTasksHandler.getCode());

                    }
                });
            }

        } else {
            priorityQueueMap.values().forEach(o -> {
                String jobResource = o.getJobResource();
                boolean queueEmpty = o.isQueueEmpty();
                if (queueEmpty) {
                    if (!StringUtils.isNullOrWhitespaceOnly(genScanCycleFlinkJobSqlFromMysql(currtime,jobResource))) {
                        final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(genScanCycleFlinkJobSqlFromMysql(currtime,jobResource),
                                FlinkJob.class, true);

                        flinkJobs.forEach(flinkJob -> {
                            if ((flinkJob.getId() - slice) % flinkConf.getScanJobsAndGenTasksHandlerCounts() == 0) {
                                o.setQueueEmpty(false);
                                flinkJob.setCurrTime(TimeUtil.localDateTimeToMilliSecond(currtime));
                                jobDealer.addScanJobsAndGenTasksJob(flinkJob, HandlerType.ScanJobsAndGenTasksHandler.getCode());

                            }
                        });
                    }

                }
            });
        }


    }

    private String genScanCycleFlinkJobSqlFromMysql(LocalDateTime currLocalDateTime,String jobResource) {
        final long currTimeStamp = TimeUtil.localDateTimeToSeconds(currLocalDateTime);
        long currTimeStampAdd = currTimeStamp + 60;
        if (currTimeStamp % 60 != 0) {
            return "";
        }
        final String scanCycleFlinkJobSqlFromMysql
                = JobConf.getScanCycleFlinkJobSqlFromMysql(flinkConf.getMysqlJobTableName(), currTimeStamp, currTimeStampAdd, jobResource);

        return scanCycleFlinkJobSqlFromMysql;

    }
}
