package handler;

import conf.FlinkConf;
import conf.JobConf;
import conf.JobTaskConf;
import enums.HandlerType;
import enums.TaskState;
import jobDealer.JobDealer;
import model.DependencyMaxCode;
import model.FlinkJob;
import model.FlinkJobDependency;
import model.FlinkJobTask;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import server.queue.GroupPriorityQueue;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;

public class DependencyCheckHandler extends ProcessFunction<Row, Row> {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    private JobDealer jobDealer;


    public DependencyCheckHandler(int splice, FlinkConf flinkConf) {
        this.slice = splice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());
        jobDealer = new JobDealer(flinkConf,mySQLJobUtil);

    }



    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime ldt = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());

        Map<String, GroupPriorityQueue> priorityQueueMap = jobDealer.getPriorityQueueMap();


        if(priorityQueueMap.size()==0){
            List<FlinkJobTask> dependencyFlinkJobTasks = scanDependencyFlinkJobTask(slice, flinkConf.getDependencyCheckHandlerCounts(), flinkConf.getMysqlJobTaskTableName());

            for (FlinkJobTask dependencyFlinkJobTask : dependencyFlinkJobTasks) {
                GroupPriorityQueue groupPriorityQueue = jobDealer.getPriorityQueueMap().get(dependencyFlinkJobTask.getResourceName());
                if (groupPriorityQueue != null) {
                    groupPriorityQueue.setQueueEmpty(false);
                }
                dependencyFlinkJobTask.setCurrTime(String.valueOf(TimeUtil.localDateTimeToSeconds(ldt)));
                jobDealer.addDependencyCheckJob(dependencyFlinkJobTask, HandlerType.DependencyCheckHandler.getCode());

            }

        }else {
            priorityQueueMap.values().forEach(o->{
                String jobResource = o.getJobResource();
                PriorityBlockingQueue<FlinkJobTask> dependencyCheckJobQueue = o.getDependencyCheckJobQueue();
                boolean queueEmpty = o.isQueueEmpty();
                if(queueEmpty){
                    final List<FlinkJobTask> flinkJobTasks
                            = mySQLJobUtil.queryList("select * from "
                                    +flinkConf.getMysqlJobTaskTableName()+" where status= '"
                                    +TaskState.DEPENDENCY.getCode()+"' and resource_name = '"+jobResource
                                    +"' order by start_time asc limit 300",
                            FlinkJobTask.class, true);
                    flinkJobTasks.forEach(dependencyFlinkJobTask -> {
                        if((dependencyFlinkJobTask.getJobId()-slice)% flinkConf.getDependencyCheckHandlerCounts()==0) {

                            o.setQueueEmpty(false);
                            dependencyFlinkJobTask.setCurrTime(String.valueOf(TimeUtil.localDateTimeToSeconds(ldt)));
                            jobDealer.addDependencyCheckJob(dependencyFlinkJobTask, HandlerType.DependencyCheckHandler.getCode());
                        }
                    });
                }
            });
        }

    }

    private List<FlinkJobTask> scanDependencyFlinkJobTask(int slice, int dependencyCheckHandlerCounts, String mysqlJobTaskTableName) {

        String scanDependencyJobTasksSql = JobTaskConf.generateScanDependencyJobTasksSql(mysqlJobTaskTableName);
        final List<FlinkJobTask> flinkJobTasks = mySQLJobUtil.queryList(scanDependencyJobTasksSql, FlinkJobTask.class, true);
        final ArrayList<FlinkJobTask> flinkJobTasks1 = new ArrayList<>();

        for (int i = 0; i < flinkJobTasks.size(); i++) {
            if((flinkJobTasks.get(i).getJobId()-slice)% flinkConf.getDependencyCheckHandlerCounts()==0){
                flinkJobTasks1.add(flinkJobTasks.get(i));

            }
        }

        return flinkJobTasks1;
    }

}
