package handler;

import conf.FlinkConf;
import conf.JobConf;
import conf.JobTaskConf;
import model.FlinkJob;
import model.FlinkJobDependency;
import model.FlinkJobTask;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DependencyCheckHandler extends ProcessFunction<Row, Row> {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;


    public DependencyCheckHandler(int splice, FlinkConf flinkConf) {
        this.slice = splice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());
    }


    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime ldt = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());
        List<FlinkJobTask> dependencyFlinkJobTasks = scanDependencyFlinkJobTask(slice, flinkConf.getDependencyCheckHandlerCounts(), flinkConf.getMysqlJobTaskTableName());

        for (FlinkJobTask dependencyFlinkJobTask : dependencyFlinkJobTasks) {
            checkDependencyAndUpdeteTaskStatus(dependencyFlinkJobTask, ldt);
        }


    }

    private void checkDependencyAndUpdeteTaskStatus(FlinkJobTask dependencyFlinkJobTask, LocalDateTime ldt) {

        boolean isSuccessCheckDependency = checkDependency(dependencyFlinkJobTask);
        if (isSuccessCheckDependency) {
            updateTaskStatus(dependencyFlinkJobTask);
        }
    }

    private void updateTaskStatus(FlinkJobTask dependencyFlinkJobTask) {
        dependencyFlinkJobTask.setStatus("1");
        final HashMap<String, Object> objectObjectHashMap = new HashMap<>();
        objectObjectHashMap.put("id", dependencyFlinkJobTask.getId());

        mySQLJobUtil.upsert(flinkConf.getMysqlJobTaskTableName(), true, dependencyFlinkJobTask, objectObjectHashMap);
    }

    private boolean checkDependency(FlinkJobTask dependencyFlinkJobTask) {
        boolean isSuccessCheckDependency = true;
        final String scheduleTimestamp = dependencyFlinkJobTask.getScheduleTime();
        final LocalDateTime localDateTime = TimeUtil.timestampToLocalDateTime(Long.parseLong(scheduleTimestamp)*1000);

//        {"dependencys":[{"jobId":1,"dependentStartTimeRule":"-1dB","dependentEndRule":"-1dE"}]}
        List<FlinkJobDependency> flinkJobDependencies = transformFlinkJobDependency(dependencyFlinkJobTask.getJobId());
//        System.out.println(flinkJobDependencies);
        for (int i = 0; i < flinkJobDependencies.size(); i++) {
            isSuccessCheckDependency = lookupDependency(flinkJobDependencies.get(i), isSuccessCheckDependency, localDateTime);
            if (!isSuccessCheckDependency) {
                break;
            }
        }
        return isSuccessCheckDependency;
    }

    private boolean lookupDependency(FlinkJobDependency flinkJobDependency, boolean isSuccessCheckDependency, LocalDateTime scheduleLocalDateTime) {
        final String sql = JobConf.generateQueryFlinkJobByIdSql(flinkConf.getMysqlJobTableName(), flinkJobDependency.getJobId());
        final FlinkJob flinkJobs = mySQLJobUtil.queryList(sql, FlinkJob.class, true).get(0);
        final String cron = flinkJobs.getCron();
        final LocalDateTime scheduleStartDependencyLocalDateTime =
                TimeUtil.getScheduleDependencyLocalDateTime(flinkJobDependency.getDependentStartTimeRule(), scheduleLocalDateTime);
        final LocalDateTime scheduleEndDependencyLocalDateTime =
                TimeUtil.getScheduleDependencyLocalDateTime(flinkJobDependency.getDependentEndRule(), scheduleLocalDateTime);
        final List<LocalDateTime> localDateTimes = CronUtils.generateDependencyParentScheduleLocalDateTimes(cron, scheduleStartDependencyLocalDateTime, scheduleEndDependencyLocalDateTime);

//        System.out.println(localDateTimes);
        int countSuccessDependency =  countSuccessDependencyFromTable(localDateTimes,flinkJobDependency.getJobId(),flinkConf.getMysqlJobTaskTableName());
        if(countSuccessDependency<localDateTimes.size()){
            isSuccessCheckDependency=false;
        }

        return  isSuccessCheckDependency;
    }

    private int countSuccessDependencyFromTable(List<LocalDateTime> localDateTimes, int jobId, String mysqlJobTaskTableName) {
        String sql = JobTaskConf.generateCountSuccessDependencyFromTableSql(localDateTimes,jobId,mysqlJobTaskTableName);
        final int i = mySQLJobUtil.queryCounts(sql);
        return i;

    }

    private List<FlinkJobDependency> transformFlinkJobDependency(int jobId) {
        String sql = JobConf.generateQueryFlinkJobByIdSql(flinkConf.getMysqlJobTableName(), jobId);
        final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(sql, FlinkJob.class, true);
        return FlinkJobDependency.tranform(flinkJobs.get(0).getDependencyConf());


    }

    private List<FlinkJobTask> scanDependencyFlinkJobTask(int slice, int dependencyCheckHandlerCounts, String mysqlJobTaskTableName) {

       String scanDependencyJobTasksSql = JobTaskConf.generateScanDependencyJobTasksSql(mysqlJobTaskTableName);
        final List<FlinkJobTask> flinkJobTasks = mySQLJobUtil.queryList(scanDependencyJobTasksSql, FlinkJobTask.class, true);
        int start = flinkJobTasks.size() / dependencyCheckHandlerCounts * slice;
        int end = flinkJobTasks.size() / dependencyCheckHandlerCounts * (slice + 1);
        final ArrayList<FlinkJobTask> flinkJobTasks1 = new ArrayList<>();

        for (int i = 0; i < flinkJobTasks.size(); i++) {
            if (slice == dependencyCheckHandlerCounts - 1) {
                if (i >= start) {
                    flinkJobTasks1.add(flinkJobTasks.get(i));

                }
            } else {
                if (i >= start && i < end) {

                    flinkJobTasks1.add(flinkJobTasks.get(i));
                }
            }
        }

        return flinkJobTasks1;
    }
}
