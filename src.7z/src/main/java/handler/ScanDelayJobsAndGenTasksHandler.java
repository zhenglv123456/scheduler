package handler;

import conf.FlinkConf;
import conf.JobConf;
import model.FlinkJob;
import model.FlinkJobTask;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import org.apache.flink.util.StringUtils;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

public class ScanDelayJobsAndGenTasksHandler extends ProcessFunction<Row, Row> {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;

    public ScanDelayJobsAndGenTasksHandler(int slice, FlinkConf flinkConf) {
        this.slice = slice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

    }

    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime currtime = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());

        if (!StringUtils.isNullOrWhitespaceOnly(genScanCycleFlinkJobSqlFromMysql(currtime))) {
            final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(genScanCycleFlinkJobSqlFromMysql(currtime), FlinkJob.class, true);

            flinkJobs.forEach(flinkJob -> {
                System.out.println(flinkJob);

                long nextScheduleTimestamp = Long.valueOf(flinkJob.getNextScheduleTime());
                long currTimestamp = TimeUtil.localDateTimeToSeconds(currtime);

                do {
                    LocalDateTime currScheduleTime = CronUtils.nextScheduleTimeOf(flinkJob.getCron(), TimeUtil.timestampToLocalDateTime(nextScheduleTimestamp * 1000));
                    LocalDateTime nextScheduleTime = CronUtils.scheduleTime(flinkJob.getCron(), currScheduleTime,1);

                    createFlinkJobTask(flinkJob, currScheduleTime);
                    updateFlinkJobNextScheduleTime(flinkJob, currScheduleTime, nextScheduleTime);
                    final long  l = TimeUtil.localDateTimeToSeconds(nextScheduleTime);

                    nextScheduleTimestamp = l;

                } while (nextScheduleTimestamp < currTimestamp);

            });
        }


    }

    private void updateFlinkJobNextScheduleTime(FlinkJob flinkJob, LocalDateTime currScheduleTime, LocalDateTime nextScheduleTime) {
        final HashMap<String, Object> stringObjectHashMap = new HashMap<>();
        stringObjectHashMap.put("id", flinkJob.getId());
//        stringObjectHashMap.put("nextScheduleTime",);
        flinkJob.setNextScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(nextScheduleTime)));
        flinkJob.setPreScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));

        mySQLJobUtil.update(flinkConf.getMysqlJobTableName(), true, flinkJob, stringObjectHashMap);
    }

    private void createFlinkJobTask(FlinkJob flinkJob, LocalDateTime currScheduleTime) {

        final FlinkJobTask flinkJobTask = new FlinkJobTask();
        flinkJobTask.setScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));
        flinkJobTask.setJobId(flinkJob.getId());
        flinkJobTask.setStatus("0");
        mySQLJobUtil.insert(flinkConf.getMysqlJobTaskTableName(), true, flinkJobTask);
    }

    private String genScanCycleFlinkJobSqlFromMysql(LocalDateTime currLocalDateTime) {
        final long currTimeStamp = TimeUtil.localDateTimeToSeconds(currLocalDateTime);
//        long currTimeStampAdd = currTimeStamp + 60;
//        if(currTimeStamp%60!=0){
//            return "";
//        }
        final String scanCycleFlinkJobSqlFromMysql
                = JobConf.getDelayScanCycleFlinkJobSqlFromMysql(flinkConf.getMysqlJobTableName(), currTimeStamp);

        return scanCycleFlinkJobSqlFromMysql;

    }
}
