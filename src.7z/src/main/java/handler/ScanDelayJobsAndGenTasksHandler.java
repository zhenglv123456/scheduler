package handler;

import conf.FlinkConf;
import conf.JobConf;
import enums.HandlerType;
import jobDealer.JobDealer;
import model.FlinkJob;
import model.FlinkJobTask;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.types.Row;
import org.apache.flink.util.Collector;
import org.apache.flink.util.StringUtils;
import server.queue.GroupPriorityQueue;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;

public class ScanDelayJobsAndGenTasksHandler extends ProcessFunction<Row, Row> {
    private int slice;
    private FlinkConf flinkConf;
    private MySQLUtil mySQLJobUtil;
    private JobDealer jobDealer;


    public ScanDelayJobsAndGenTasksHandler(int slice, FlinkConf flinkConf) {
        this.slice = slice;
        this.flinkConf = flinkConf;
    }

    @Override
    public void open(Configuration parameters) {
        mySQLJobUtil = new MySQLUtil(flinkConf.getMysqlJobUrl(), flinkConf.getMysqlJobUsername(), flinkConf.getMysqlJobPassword()
                , flinkConf.getMysqlJobMaxConnect(), flinkConf.getMysqlJobMinConnect());

        jobDealer=new JobDealer(flinkConf,mySQLJobUtil);

    }

    @Override
    public void processElement(Row row, Context context, Collector<Row> collector) throws Exception {
        final LocalDateTime currtime = (LocalDateTime) row.getField(flinkConf.getLocalTimeStampFieldName());

        // 延迟恢复任务只需启动的时候执行一次
        // todo 将重跑任务的轮询也合并到此handler中
        if(!StringUtils.isNullOrWhitespaceOnly(genScanCycleFlinkJobSqlFromMysql(currtime,null))){
            Map<String, GroupPriorityQueue> priorityQueueMap = jobDealer.getPriorityQueueMap();

            if(priorityQueueMap.size()==0){
                final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(genScanCycleFlinkJobSqlFromMysql(currtime,null),
                        FlinkJob.class, true);

                flinkJobs.forEach(flinkJob -> {
                    if((flinkJob.getId()-slice)% flinkConf.getScanDelayJobsAndGenTasksHandlerCounts()==0){
                        GroupPriorityQueue groupPriorityQueue = jobDealer.getPriorityQueueMap().get(flinkJob.getResourceName());
                        if(groupPriorityQueue!=null){
                            groupPriorityQueue.setQueueEmpty(false);
                        }
                        flinkJob.setCurrTime(TimeUtil.localDateTimeToSeconds(currtime));
                        jobDealer.addScanDelayJobsAndGenTasksJob(flinkJob, HandlerType.ScanDelayJobsAndGenTasksHandler.getCode());

                    }
                });
            }else{
                priorityQueueMap.values().forEach(o->{

                });
            }
        }


    }



    private String genScanCycleFlinkJobSqlFromMysql(LocalDateTime currLocalDateTime,String resourceName) {
        final long currTimeStamp = TimeUtil.localDateTimeToSeconds(currLocalDateTime);
//        long currTimeStampAdd = currTimeStamp + 60;
//        if(currTimeStamp%60!=0){
//            return "";
//        }
        final String scanCycleFlinkJobSqlFromMysql
                = JobConf.getDelayScanCycleFlinkJobSqlFromMysql(flinkConf.getMysqlJobTableName(), currTimeStamp,resourceName);

        return scanCycleFlinkJobSqlFromMysql;

    }
}
