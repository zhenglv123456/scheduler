package handler;

import conf.FlinkConf;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableResult;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.types.Row;

public class DataGenSourceHandler {
    public static DataStream<Row> getSourceTable(StreamTableEnvironment streamTableEnvironment, FlinkConf flinkConf) {
        streamTableEnvironment.executeSql(flinkConf.getSourDataGenderSql());
        final Table table = streamTableEnvironment.sqlQuery(flinkConf.getSourDataGenderSqlquery());
        return streamTableEnvironment.toDataStream(table);

    }
}
