import service.ExecuteService;
import service.Service;
import service.ServiceFactory;

public class FlinkSchedulerRunner {

    public static void main(String[] args) {

        final Service service = ServiceFactory.getInstance(ExecuteService.class);
        service.init();
        service.start();
    }
}
