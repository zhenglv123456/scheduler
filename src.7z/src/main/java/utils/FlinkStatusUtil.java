package utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import okhttp3.Response;

import java.io.IOException;

public class FlinkStatusUtil {
    static String jobName = "97c5216de4ef4b15b16de3a3ab53fd78";
    static String urlPrefix = "http://192.168.1.127:8081";

    public static void main(String[] args) throws IOException {
        String jobID = getJobID(urlPrefix, jobName);
//        getJobState(urlPrefix, jobID);
//        stop(urlPrefix, jobID);


        try {
            while (true) {
                getJobState(urlPrefix, jobID);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
        }


    }

    /*若任务的状态为running，则调用api结束任务*/
//    public static void stop(String urlPrefix, String jid) throws IOException {
//        CloseableHttpResponse stopJob = send(new HttpPatch(urlPrefix + "/jobs/" + jid));
//        StatusLine statusLine = stopJob.getStatusLine();
//        int statusCode = statusLine.getStatusCode();
//        /*202代表执行成功，关闭pipeline*/
//        if (statusCode != 202) {
//            throw new RuntimeException("当前任务未能正确关闭");
//        }
//
//    }

    /*判断当前任务的状态   "state": "RUNNING" */
    public static String getJobState(String urlPrefix, String jid) throws IOException {
        final Response data = OkHttpClientUtil.getInstance().getData(urlPrefix + "/jobs/" + jid);
        final String getJobIDRes = data.body().string();

        JSONObject jsonObject = JSON.parseObject(getJobIDRes);
        String state = jsonObject.getString("state");
       return state;
    }

    /*根据jobname获取jobid*/
    public static String getJobID(String urlPrefix, String jobName) throws IOException {
        final Response data = OkHttpClientUtil.getInstance().getData(urlPrefix + "/jobs/overview");
        final String getJobIDRes = data.body().string();
//        CloseableHttpResponse getJobID = send(new HttpGet(urlPrefix + "/jobs/overview"));
//        String getJobIDRes = transform(data);
        JSONObject res = JSON.parseObject(getJobIDRes);
        JSONArray jobs = res.getJSONArray("jobs");
        String jid = null;
        for (int i = 0; i < jobs.size(); i++) {
            JSONObject jsonObject = (JSONObject) jobs.get(i);
            String name = (String) jsonObject.get("name");
            if (name.equals(jobName)) {
                jid = (String) jsonObject.get("jid");
                break;
            }
        }
        return jid;
    }


//    public static String transform(CloseableHttpResponse response) throws IOException {
//        HttpEntity entity = response.getEntity();
//        String result = EntityUtils.toString(entity);
//        return result;
//    }


}
