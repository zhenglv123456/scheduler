package utils;

import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ResourceBundle;

public class ModelUtil {
    public static ResourceBundle localConfig = ResourceBundle.getBundle("localConfig");
    public static ResourceBundle config = ResourceBundle.getBundle("config");

    public static Logger logger = LoggerFactory.getLogger(ModelUtil.class);

    /**
     * 根据key获取配置值
     *
     * @param key 配置参数的key
     * @return 配置参数的value
     */
    public static String getConfigValue(String key) {
        if (SystemUtils.IS_OS_WINDOWS) {
            return localConfig.getString(key);
        } else {
            return config.getString(key);
        }
    }

}
