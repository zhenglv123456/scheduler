package utils;

public class RegexpUtils {
    // 匹配两个点
    public static String REGEXP_TWOPOINT = "(\\w+\\.)+\\w+(\\w+\\.)+\\w+";
    public static String SPLIT_POINT = "\\.";
    public static String SESSIONS = "sessions";
    public static String OPERATIONS = "operations";
    public static String STATEMENTS = "statements";
    public static String STATEMENT = "statement";
}
