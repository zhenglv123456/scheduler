package utils;

import enums.DateCalRule;
import org.apache.flink.util.StringUtils;

import java.time.*;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TimeUtil {
    public static void main(String[] args) {
        getScheduleDependencyLocalDateTime("-2dB", LocalDateTime.now());
    }

    // s,m,mE,mB,H,HB,HE,d,dB,dE,w,wB,wE,M,MB,ME
    // calRule: +6d-1w+0wB+1d
    public static LocalDateTime getScheduleDependencyLocalDateTime(String calRule, LocalDateTime taskCurrScheduleTime) {
        LocalDateTime newLocalDateTime = taskCurrScheduleTime;
        List<String> ruleList = getSliceRuleList(calRule);
        for (String rule : ruleList) {
            if (org.apache.commons.lang3.StringUtils.isBlank(rule)) {
                continue;
            }
            int minNumberIndex = StringUtil.getStringMinNumberIndex(rule);
            final long calNumber = Long.parseLong(rule.substring(0, minNumberIndex));
            final String calRuleSingle = rule.substring(minNumberIndex, rule.length());
            newLocalDateTime = processCalRule(newLocalDateTime, calNumber, calRuleSingle);
        }
        return newLocalDateTime;
    }

    private static LocalDateTime processCalRule(LocalDateTime taskCurrScheduleTime, long calNumber, String calRule) {
        final DateCalRule calRuleEnum = DateCalRule.getCalRuleEnum(calRule);
        LocalDateTime localDateTime = taskCurrScheduleTime;
        switch (calRuleEnum) {
            case d:
                localDateTime = taskCurrScheduleTime.plusDays(calNumber);
                break;
            case dB:
                localDateTime = taskCurrScheduleTime.plusDays(calNumber).with(LocalTime.MIN);
                break;
            case dE:
                localDateTime = taskCurrScheduleTime.plusDays(calNumber).with(LocalTime.MAX);
                break;
            case H:
                localDateTime = taskCurrScheduleTime.plusHours(calNumber);
                break;
            case HB:
                localDateTime = LocalDateTime.of(LocalDate.from(taskCurrScheduleTime.plusHours(calNumber)),
                        LocalTime.of(taskCurrScheduleTime.plusHours(calNumber).getHour(), 0, 0));
                break;
            case HE:
                localDateTime = LocalDateTime.of(LocalDate.from(taskCurrScheduleTime.plusHours(calNumber)),
                        LocalTime.of(taskCurrScheduleTime.plusHours(calNumber).getHour(), 59, 59));
                break;
            case w:
                localDateTime = taskCurrScheduleTime.plusWeeks(calNumber);
                break;
            case wB:
                localDateTime = getWeekBegin(taskCurrScheduleTime.plusWeeks(calNumber));
                break;
            case wE:
                localDateTime = getWeekEnd(taskCurrScheduleTime.plusWeeks(calNumber));
                break;
            case M:
                localDateTime = taskCurrScheduleTime.plusMonths(calNumber);
                break;
            case MB:
                localDateTime = taskCurrScheduleTime.plusMonths(calNumber).with(TemporalAdjusters.firstDayOfMonth()).with(LocalTime.MIN);
                break;
            case ME:
                localDateTime = taskCurrScheduleTime.plusMonths(calNumber).with(TemporalAdjusters.lastDayOfMonth()).with(LocalTime.MAX);
                break;

        }

        return localDateTime;
    }

    private static LocalDateTime getWeekEnd(LocalDateTime week) {
        final int value = week.getDayOfWeek().getValue();
        final LocalDateTime localDateTime = week.minusDays(6-value).with(LocalTime.MAX);

        return localDateTime;
    }

    private static LocalDateTime getWeekBegin(LocalDateTime week) {
        final int value = week.getDayOfWeek().getValue();
        final LocalDateTime localDateTime = week.minusDays(value).with(LocalTime.MIN);

        return localDateTime;

    }

    private static List<String> getSliceRuleList(String calRule) {
        final ArrayList<String> rules = new ArrayList<>();
        for (String s : calRule.split("\\+")) {

            if (!StringUtils.isNullOrWhitespaceOnly(s)) {
                if (!s.contains("-")) {
                    rules.add(s);
                } else {
                    final String[] split = s.split("-");
                    for (int i = 0; i < split.length; i++) {
                        if (i == 0) {
                            rules.add(split[i]);
                        } else {
                            rules.add("-" + split[i]);
                        }
                    }
                }
            }

        }
        return rules;

    }


    private static final ZoneId ZONE_ID = ZoneOffset.systemDefault();
    /**
     * 8小时的秒数
     */
    private static final int OFFSET = 8 * 60 * 60;


    /**
     * LocalDateTime -> 秒
     *
     * @param localDateTime localDateTime
     * @return 秒
     */
    public static long localDateTimeToSeconds(LocalDateTime localDateTime) {
        return localDateTime.atZone(ZONE_ID).toEpochSecond();
    }

    /**
     * LocalDateTime -> 毫秒
     * 竟然加了8小时
     *
     * @param localDateTime localDateTime
     * @return 毫秒
     */
    public static long localDateTimeToMilliSecond(LocalDateTime localDateTime) {
        // 比标准实际慢8小时，就是当前的时间了。
        return localDateTime.toInstant(ZoneOffset.ofTotalSeconds(OFFSET)).toEpochMilli();
    }

    public static LocalDateTime timestampToLocalDateTime(long timestamp) {
        // 创建时间
        Date date = new Date(timestamp);
        // 将时间转为 LocalDateTime
        LocalDateTime localDateTime = date.toInstant().atOffset(ZoneOffset.ofHours(8)).toLocalDateTime();
        return localDateTime;
    }


}
