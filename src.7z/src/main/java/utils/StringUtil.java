package utils;

public class StringUtil {

    public static int getStringMinNumberIndex(String rule) {
        int index = -1;
        final char[] chars = rule.toLowerCase().toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if(chars[i]>='a'&&chars[i]<='z'){
                index=i;
                break;
            }
        }

        return index;
    }
}
