package meta.model;

import java.time.LocalDateTime;

public interface IResult {

    void setStartTime(LocalDateTime startTime);

    String getJobId();
}
