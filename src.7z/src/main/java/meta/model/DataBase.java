package meta.model;

import lombok.Data;
import meta.base.driver.DriverConfig;

import java.time.LocalDateTime;

@Data
public class DataBase {
    private static final long serialVersionUID = -5002272138861566408L;
    private int id;

    private  String name;

    private String alias;

    private String groupName;

    private String type;

    private String flinkConnectorType;

    private String driverClass;

    private String url;

    private String username;

    private String password;

    private String note;

    private String flinkConfig;

    private String flinkTemplate;

    private String dbVersion;

    private Boolean status;

    private LocalDateTime healthTime;

    private LocalDateTime heartbeatTime;

    public DriverConfig getDriverConfig() {
        return new DriverConfig(getName(), type, url, username, password);
    }
}
