package meta.exception;

public class MetaDataException extends RuntimeException {

    public MetaDataException(String message, Throwable cause) {
        super(message, cause);
    }

    public MetaDataException(String message) {
        super(message);
    }
}
