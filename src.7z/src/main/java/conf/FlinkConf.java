package conf;

import org.apache.flink.configuration.Configuration;
import utils.ModelUtil;

import java.io.Serializable;

public class FlinkConf implements Serializable {

    private Configuration configuration;

    private boolean disableOperatorChaining;

    private Integer setParallelism;

    private String sourDataGenderSql;
    private String sourDataGenderSqlquery;
    private String flinkJobName;
    private String localTimeStampFieldName;
    private int dependencyCheckHandlerCounts;
    private int scanJobsAndGenTasksHandlerCounts;
    private int scanDelayJobsAndGenTasksHandlerCounts;
    private int executeSuccessDependencyJobTaskHandlerCounts;
    private int CheckRunningTaskStatusHandlerCounts;


    private String mysqlJobUrl;
    private String mysqlJobUsername;
    private String mysqlJobPassword;
    private String mysqlJobTableName;
    private int mysqlJobMaxConnect;
    private int mysqlJobMinConnect;


    private String mysqlJobTaskUrl;
    private String mysqlJobTaskUsername;
    private String mysqlJobTaskPassword;
    private String mysqlJobTaskTableName;
    private int mysqlJobTaskMaxConnect;
    private int mysqlJobTaskMinConnect;

    private  String flinkSqlGatewayUrl;
    private String flinkJobsUrl;


    public void init() {

        configuration = new Configuration();
//        configuration.setBoolean("classloader.check-leaked-classloader",false);
        configuration.setInteger("rest.port", Integer.parseInt(ModelUtil.getConfigValue("flink.rest.port")));
        disableOperatorChaining = Boolean.parseBoolean(ModelUtil.getConfigValue("flink.disableOperatorChaining"));
        setParallelism = Integer.valueOf(ModelUtil.getConfigValue("flink.setParallelism"));
        sourDataGenderSql = ModelUtil.getConfigValue("flink.sourDataGenderSql");
        localTimeStampFieldName = ModelUtil.getConfigValue("flink.localTimeStampFieldName");
        sourDataGenderSqlquery = ModelUtil.getConfigValue("flink.sourDataGenderSqlquery");
        flinkJobName = ModelUtil.getConfigValue("flink.job.name");
        dependencyCheckHandlerCounts = Integer.parseInt(ModelUtil.getConfigValue("flink.dependencyCheckHandlerCounts"));
        scanJobsAndGenTasksHandlerCounts = Integer.parseInt(ModelUtil.getConfigValue("flink.scanJobsAndGenTasksHandlerCounts"));
        scanDelayJobsAndGenTasksHandlerCounts = Integer.parseInt(ModelUtil.getConfigValue("flink.scanDelayJobsAndGenTasksHandlerCounts"));
        executeSuccessDependencyJobTaskHandlerCounts = Integer.parseInt(ModelUtil.getConfigValue("flink.executeSuccessDependencyJobTaskHandlerCounts"));
        CheckRunningTaskStatusHandlerCounts= Integer.parseInt(ModelUtil.getConfigValue("flink.CheckRunningTaskStatusHandlerCounts"));


        mysqlJobUrl = ModelUtil.getConfigValue("mysql.job.data.url");
        mysqlJobUsername = ModelUtil.getConfigValue("mysql.job.data.username");
        mysqlJobPassword = ModelUtil.getConfigValue("mysql.job.data.password");
        mysqlJobMaxConnect = Integer.parseInt(ModelUtil.getConfigValue("mysql.job.data.maxConnect"));
        mysqlJobMinConnect = Integer.parseInt(ModelUtil.getConfigValue("mysql.job.data.minConnect"));
        mysqlJobTableName = ModelUtil.getConfigValue("mysql.job.tableName");

        mysqlJobTaskUrl = ModelUtil.getConfigValue("mysql.job.task.data.url");
        mysqlJobTaskUsername = ModelUtil.getConfigValue("mysql.job.task.data.username");
        mysqlJobTaskPassword = ModelUtil.getConfigValue("mysql.job.task.data.password");
        mysqlJobTaskMaxConnect = Integer.parseInt(ModelUtil.getConfigValue("mysql.job.task.data.maxConnect"));
        mysqlJobTaskMinConnect = Integer.parseInt(ModelUtil.getConfigValue("mysql.job.task.data.minConnect"));
        mysqlJobTaskTableName = ModelUtil.getConfigValue("mysql.job.task.tableName");


        flinkSqlGatewayUrl = ModelUtil.getConfigValue("flinkSqlGatewayUrl");
        flinkJobsUrl = ModelUtil.getConfigValue("flinkJobsUrl");

    }

    public int getCheckRunningTaskStatusHandlerCounts() {
        return CheckRunningTaskStatusHandlerCounts;
    }

    public void setCheckRunningTaskStatusHandlerCounts(int checkRunningTaskStatusHandlerCounts) {
        CheckRunningTaskStatusHandlerCounts = checkRunningTaskStatusHandlerCounts;
    }

    public String getFlinkJobsUrl() {
        return flinkJobsUrl;
    }

    public String getMysqlJobTableName() {
        return mysqlJobTableName;
    }

    public String getMysqlJobTaskTableName() {
        return mysqlJobTaskTableName;
    }

    public String getMysqlJobUrl() {
        return mysqlJobUrl;
    }

    public String getMysqlJobUsername() {
        return mysqlJobUsername;
    }

    public String getMysqlJobPassword() {
        return mysqlJobPassword;
    }

    public int getMysqlJobMaxConnect() {
        return mysqlJobMaxConnect;
    }

    public int getMysqlJobMinConnect() {
        return mysqlJobMinConnect;
    }

    public String getMysqlJobTaskUrl() {
        return mysqlJobTaskUrl;
    }

    public String getMysqlJobTaskUsername() {
        return mysqlJobTaskUsername;
    }

    public String getMysqlJobTaskPassword() {
        return mysqlJobTaskPassword;
    }

    public int getMysqlJobTaskMaxConnect() {
        return mysqlJobTaskMaxConnect;
    }

    public int getMysqlJobTaskMinConnect() {
        return mysqlJobTaskMinConnect;
    }

    public String getLocalTimeStampFieldName() {
        return localTimeStampFieldName;
    }

    public int getScanJobsAndGenTasksHandlerCounts() {
        return scanJobsAndGenTasksHandlerCounts;
    }

    public int getScanDelayJobsAndGenTasksHandlerCounts() {
        return scanDelayJobsAndGenTasksHandlerCounts;
    }

    public int getDependencyCheckHandlerCounts() {
        return dependencyCheckHandlerCounts;
    }

    public String getFlinkJobName() {
        return flinkJobName;
    }

    public String getSourDataGenderSqlquery() {
        return sourDataGenderSqlquery;
    }

    public String getSourDataGenderSql() {
        return sourDataGenderSql;
    }

    public Configuration getConfiguration() {
        return configuration;
    }

    public void setConfiguration(Configuration configuration) {
        this.configuration = configuration;
    }

    public boolean isDisableOperatorChaining() {
        return disableOperatorChaining;
    }

    public void setDisableOperatorChaining(boolean disableOperatorChaining) {
        this.disableOperatorChaining = disableOperatorChaining;
    }

    public Integer getSetParallelism() {
        return setParallelism;
    }

    public void setSetParallelism(Integer setParallelism) {
        this.setParallelism = setParallelism;
    }

    public int getExecuteSuccessDependencyJobTaskHandlerCounts() {
        return executeSuccessDependencyJobTaskHandlerCounts;
    }

    public String getFlinkSqlGatewayUrl() {
        return  flinkSqlGatewayUrl;
    }
}
