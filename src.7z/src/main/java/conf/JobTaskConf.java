package conf;

import org.apache.commons.lang3.StringUtils;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.List;

public class JobTaskConf {

    public static String queryDependencyTaskTotalCounts = "select count(1) as cnts from %s where status='0'";
    public static String scanDependencyJobTasksSql = "select * from %s where status='0'";
    public static String countSuccessDependencyFromTableSql = "select count(1) as cnts  from %s where status = '4' and job_id= %s and code in %s";

    public static String generateQueryDependencyMaxCodesFromTableSql
            ="select schedule_time,max(code) as code from %s where job_id = %s and schedule_time in %s group by schedule_time";
    public static String scanWaitToExecuteFlinkJobTaskSql = "select * from %s where status='1'";
    public static String scanWaitToExecuteFlinkJobTaskSqlByResource = "select * from %s where status='1' and resource_name = '%s'";

    public static String scanQueryDependencyTaskTotalCountsSQL(String tableName) {

        return String.format(queryDependencyTaskTotalCounts, tableName);

    }

    public static String scanQueryDependencySliceJobTaskSql(String mysqlJobTaskTableName, int Start, int end) {

        return "";
    }

    public static String generateScanDependencyJobTasksSql(String mysqlJobTaskTableName) {
        return String.format(scanDependencyJobTasksSql, mysqlJobTaskTableName);

    }

    public static String generateCountSuccessDependencyFromTableSql(String codeString, int jobId, String mysqlJobTaskTableName) {
        return String.format(countSuccessDependencyFromTableSql,mysqlJobTaskTableName,jobId,codeString);

    }

    private static String localDateTimesListToString(List<LocalDateTime> localDateTimes) {
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("( ");
        for (int i = 0; i < localDateTimes.size(); i++) {
            if(i==localDateTimes.size()-1){
                stringBuilder.append("'").append(TimeUtil.localDateTimeToSeconds(localDateTimes.get(i))).append("')");
            }else {

                stringBuilder.append("'").append(TimeUtil.localDateTimeToSeconds(localDateTimes.get(i))).append("',");
            }
        }

        return stringBuilder.toString();
    }

    public static String generateScanWaitToExecuteFlinkJobTaskSql(String mysqlJobTaskTableName,String jobResource) {
        return StringUtils.isBlank(jobResource)?
                String.format(scanWaitToExecuteFlinkJobTaskSql,mysqlJobTaskTableName):
                String.format(scanWaitToExecuteFlinkJobTaskSqlByResource,mysqlJobTaskTableName,jobResource);
    }

    public static String generateQueryDependencyMaxCodesFromTableSql(List<LocalDateTime> localDateTimes, int jobId, String mysqlJobTaskTableName) {
        String localDateTimesListToString = localDateTimesListToString(localDateTimes);
        return String.format(generateQueryDependencyMaxCodesFromTableSql,mysqlJobTaskTableName,jobId,localDateTimesListToString);
    }
}
