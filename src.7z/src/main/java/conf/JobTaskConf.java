package conf;

import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.List;

public class JobTaskConf {

    public static String queryDependencyTaskTotalCounts = "select count(1) as cnts from %s where status='0'";
    public static String scanDependencyJobTasksSql = "select * from %s where status='0'";
    public static String countSuccessDependencyFromTableSql = "select count(1) as cnts  from %s where status = '1' and job_id= %s and schedule_time in %s";

    public static String scanWaitToExecuteFlinkJobTaskSql = "select * from %s where status='1'";

    public static String scanQueryDependencyTaskTotalCountsSQL(String tableName) {

        return String.format(queryDependencyTaskTotalCounts, tableName);

    }

    public static String scanQueryDependencySliceJobTaskSql(String mysqlJobTaskTableName, int Start, int end) {

        return "";
    }

    public static String generateScanDependencyJobTasksSql(String mysqlJobTaskTableName) {
        return String.format(scanDependencyJobTasksSql, mysqlJobTaskTableName);

    }

    public static String generateCountSuccessDependencyFromTableSql(List<LocalDateTime> localDateTimes, int jobId, String mysqlJobTaskTableName) {
        String localDateTimesListToString = localDateTimesListToString(localDateTimes);
        return String.format(countSuccessDependencyFromTableSql,mysqlJobTaskTableName,jobId,localDateTimesListToString);

    }

    private static String localDateTimesListToString(List<LocalDateTime> localDateTimes) {
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("( ");
        for (int i = 0; i < localDateTimes.size(); i++) {
            if(i==localDateTimes.size()-1){
                stringBuilder.append("'").append(TimeUtil.localDateTimeToSeconds(localDateTimes.get(i))).append("')");
            }else {

                stringBuilder.append("'").append(TimeUtil.localDateTimeToSeconds(localDateTimes.get(i))).append("',");
            }
        }

        return stringBuilder.toString();
    }

    public static String generateScanWaitToExecuteFlinkJobTaskSql(String mysqlJobTaskTableName) {
        return String.format(scanWaitToExecuteFlinkJobTaskSql,mysqlJobTaskTableName);
    }
}
