package conf;

public class JobConf {
    public static String scanCycleFlinkJobSqlFromMysql
            = "SELECT * FROM %s WHERE STATUS='0' AND ( NEXT_SCHEDULE_TIME IS NULL OR NEXT_SCHEDULE_TIME='' OR " +
            "(NEXT_SCHEDULE_TIME>=%s AND NEXT_SCHEDULE_TIME<%s) )";

    public static String scanDelayCycleFlinkJobSqlFromMysql
            = "SELECT * FROM %s WHERE STATUS='0' AND ( NEXT_SCHEDULE_TIME IS not NULL and NEXT_SCHEDULE_TIME !='' and " +
            "NEXT_SCHEDULE_TIME<%s )";

    public static String queryFlinkJobByIdSql = "select * from %s where id =  %s ";

    public static String getScanCycleFlinkJobSqlFromMysql(String tableName, long currenSecond, long currenSecondAdd){
        return String.format(scanCycleFlinkJobSqlFromMysql,tableName,currenSecond,currenSecondAdd);
    }

    public static String getDelayScanCycleFlinkJobSqlFromMysql(String tableName, long currenSecond){
        return String.format(scanDelayCycleFlinkJobSqlFromMysql,tableName,currenSecond);
    }

    public static String generateQueryFlinkJobByIdSql(String mysqlJobTableName, int jobId) {
        return String.format(queryFlinkJobByIdSql,mysqlJobTableName,jobId);
    }
}
