package conf;

import org.apache.commons.lang3.StringUtils;

public class JobConf {
    public static String scanCycleFlinkJobSqlFromMysql
            = "SELECT * FROM %s WHERE STATUS='0' AND ( NEXT_SCHEDULE_TIME IS NULL OR NEXT_SCHEDULE_TIME='' OR " +
            "(NEXT_SCHEDULE_TIME>=%s AND NEXT_SCHEDULE_TIME<%s) )";

    public static String scanCycleFlinkJobSqlFromMysqlByResourceName
            = "SELECT * FROM %s WHERE STATUS='0' AND ( NEXT_SCHEDULE_TIME IS NULL OR NEXT_SCHEDULE_TIME='' OR " +
            "(NEXT_SCHEDULE_TIME>=%s AND NEXT_SCHEDULE_TIME<%s) ) and resource_name='%s'";

    public static String scanDelayCycleFlinkJobSqlFromMysql
            = "SELECT * FROM %s WHERE STATUS='0' AND ( NEXT_SCHEDULE_TIME IS not NULL and NEXT_SCHEDULE_TIME !='' and " +
            "NEXT_SCHEDULE_TIME<%s )";
    public static String scanDelayCycleFlinkJobSqlFromMysqlByResourceName
            = "SELECT * FROM %s WHERE STATUS='0' AND ( NEXT_SCHEDULE_TIME IS not NULL and NEXT_SCHEDULE_TIME !='' and " +
            "NEXT_SCHEDULE_TIME<%s ) and resource_name='%s'";

    public static String queryFlinkJobByIdSql = "select * from %s where id =  %s ";

    public static String getScanCycleFlinkJobSqlFromMysql(String tableName, long currenSecond, long currenSecondAdd,String resourceName){
        return StringUtils.isBlank(resourceName)?
                String.format(scanCycleFlinkJobSqlFromMysql,tableName,currenSecond,currenSecondAdd)
                :String.format(scanCycleFlinkJobSqlFromMysqlByResourceName,tableName,currenSecond,currenSecondAdd,resourceName);
    }

    public static String getDelayScanCycleFlinkJobSqlFromMysql(String tableName, long currenSecond,String resourceName){
        return StringUtils.isBlank(resourceName)?
                String.format(scanDelayCycleFlinkJobSqlFromMysql,tableName,currenSecond)
                :String.format(scanDelayCycleFlinkJobSqlFromMysqlByResourceName,tableName,currenSecond,resourceName);

    }

    public static String generateQueryFlinkJobByIdSql(String mysqlJobTableName, int jobId) {
        return String.format(queryFlinkJobByIdSql,mysqlJobTableName,jobId);
    }
}
