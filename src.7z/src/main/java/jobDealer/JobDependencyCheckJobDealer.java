package jobDealer;

import conf.FlinkConf;
import conf.JobConf;
import conf.JobTaskConf;
import enums.TaskState;
import model.DependencyMaxCode;
import model.FlinkJob;
import model.FlinkJobDependency;
import model.FlinkJobTask;
import server.queue.BlockCallerPolicy;
import server.queue.GroupPriorityQueue;
import taskPlugins.TaskPluginManager;
import threadfactory.CustomThreadFactory;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.*;

public class JobDependencyCheckJobDealer  implements Runnable {
    private GroupPriorityQueue groupPriorityQueue;

    private PriorityBlockingQueue<FlinkJobTask> dependencyCheckJobQueue = null;

    private ExecutorService jobSubmitConcurrentService;

    private int jobSubmitConcurrent = 1;
    private String jobResource = null;
    private TaskPluginManager taskPluginManager;
//    private AbstractTask task;


    public JobDependencyCheckJobDealer(GroupPriorityQueue groupPriorityQueue) {
        this.groupPriorityQueue = groupPriorityQueue;
        this.dependencyCheckJobQueue = groupPriorityQueue.getDependencyCheckJobQueue();
        this.jobResource = groupPriorityQueue.getJobResource();
        this.jobSubmitConcurrentService =
                new ThreadPoolExecutor(jobSubmitConcurrent, jobSubmitConcurrent, 60L, TimeUnit.SECONDS,
                        new SynchronousQueue<>(true),
                        new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmitConcurrent"),
                        new BlockCallerPolicy());
        this.taskPluginManager = new TaskPluginManager();
        taskPluginManager.installPlugin();
    }

    @Override
    public void run() {
        while (true) {
            try {
                FlinkJobTask jobClient = dependencyCheckJobQueue.take();


                //提交任务
                jobSubmitConcurrentService.submit(() -> {
                    try {
                        submitJob(jobClient);
                    } catch (Exception e) {
                        e.printStackTrace();
                        dependencyCheckJobQueue.add(jobClient);
                    }
                });
            } catch (Exception e) {
//                LOGGER.error("", e);
            } finally {
                if (groupPriorityQueue.getDependencyCheckJobQueue().size() == 0) {
                    groupPriorityQueue.setQueueEmpty(true);
                }
            }
        }
    }

    private void submitJob(FlinkJobTask flinkJobTask) throws Exception {
        final MySQLUtil mySQLJobUtil = groupPriorityQueue.getJobDealer().getMySQLUtil();
        final FlinkConf flinkConf = groupPriorityQueue.getJobDealer().getFlinkConf();
        try {

            checkDependencyAndUpdeteTaskStatus(flinkJobTask, mySQLJobUtil,flinkConf);


        } catch (Exception e) {
            e.printStackTrace();
        }



    }

    private void checkDependencyAndUpdeteTaskStatus(FlinkJobTask dependencyFlinkJobTask, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {

        boolean isSuccessCheckDependency = checkDependency(dependencyFlinkJobTask,mySQLJobUtil,flinkConf);
        if (isSuccessCheckDependency) {
            updateTaskStatus(dependencyFlinkJobTask,mySQLJobUtil,flinkConf);
        }
    }


    private void updateTaskStatus(FlinkJobTask dependencyFlinkJobTask, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {
        dependencyFlinkJobTask.setStatus(String.valueOf(TaskState.DEPENDENTSUCCESS.getCode()));
        final HashMap<String, Object> objectObjectHashMap = new HashMap<>();
        objectObjectHashMap.put("id", dependencyFlinkJobTask.getId());
        objectObjectHashMap.put("code", dependencyFlinkJobTask.getCode());

        mySQLJobUtil.upsert(flinkConf.getMysqlJobTaskTableName(), true, dependencyFlinkJobTask, objectObjectHashMap);
    }

    private boolean checkDependency(FlinkJobTask dependencyFlinkJobTask, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {
        boolean isSuccessCheckDependency = true;
        final String scheduleTimestamp = dependencyFlinkJobTask.getScheduleTime();
        final LocalDateTime localDateTime = TimeUtil.timestampToLocalDateTime(Long.parseLong(scheduleTimestamp)*1000);

//        {"dependencys":[{"jobId":1,"dependentStartTimeRule":"-1dB","dependentEndRule":"-1dE"}]}
        List<FlinkJobDependency> flinkJobDependencies = transformFlinkJobDependency(dependencyFlinkJobTask.getJobId(),mySQLJobUtil,flinkConf);
//        System.out.println(flinkJobDependencies);
        for (int i = 0; i < flinkJobDependencies.size(); i++) {
            isSuccessCheckDependency = lookupDependency(flinkJobDependencies.get(i), isSuccessCheckDependency, localDateTime,mySQLJobUtil,flinkConf);
            if (!isSuccessCheckDependency) {
                break;
            }
        }
        return isSuccessCheckDependency;
    }

    private boolean lookupDependency(FlinkJobDependency flinkJobDependency, boolean isSuccessCheckDependency, LocalDateTime scheduleLocalDateTime, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {
        final String sql = JobConf.generateQueryFlinkJobByIdSql(flinkConf.getMysqlJobTableName(), flinkJobDependency.getJobId());
        final FlinkJob flinkJobs = mySQLJobUtil.queryList(sql, FlinkJob.class, true).get(0);
        final String cron = flinkJobs.getCron();
        final LocalDateTime scheduleStartDependencyLocalDateTime =
                TimeUtil.getScheduleDependencyLocalDateTime(flinkJobDependency.getDependentStartTimeRule(), scheduleLocalDateTime);
        final LocalDateTime scheduleEndDependencyLocalDateTime =
                TimeUtil.getScheduleDependencyLocalDateTime(flinkJobDependency.getDependentEndRule(), scheduleLocalDateTime);
        final List<LocalDateTime> localDateTimes = CronUtils.generateDependencyParentScheduleLocalDateTimes(cron, scheduleStartDependencyLocalDateTime, scheduleEndDependencyLocalDateTime);

        int countSuccessDependency =  countSuccessDependencyFromTable(localDateTimes,flinkJobDependency.getJobId(),flinkConf.getMysqlJobTaskTableName(),mySQLJobUtil,flinkConf);
        if(countSuccessDependency<localDateTimes.size()){
            isSuccessCheckDependency=false;
        }

        return  isSuccessCheckDependency;
    }

    private int countSuccessDependencyFromTable(List<LocalDateTime> localDateTimes, int jobId, String mysqlJobTaskTableName, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {
        // 先查询出调度时间对应的最大执行记录的code
        int i = 0;
        String codesSql  = JobTaskConf.generateQueryDependencyMaxCodesFromTableSql(localDateTimes,jobId,mysqlJobTaskTableName);
        List<DependencyMaxCode>  dependencyMaxCodes =  mySQLJobUtil.queryList(codesSql,DependencyMaxCode.class,true);

        if(dependencyMaxCodes.size()==0){
            return i;
        }
        String codeString = codeListToString(dependencyMaxCodes);

        // 根据code统计执行成功的个数并返回
        String sql = JobTaskConf.generateCountSuccessDependencyFromTableSql(codeString,jobId,mysqlJobTaskTableName);

        i = mySQLJobUtil.queryCounts(sql);


        return i;

    }

    private String codeListToString(List<DependencyMaxCode> dependencyMaxCodes) {
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("( ");
        for (int i = 0; i < dependencyMaxCodes.size(); i++) {
            if(i==dependencyMaxCodes.size()-1){
                stringBuilder.append("'").append(dependencyMaxCodes.get(i).getCode()).append("')");
            }else {

                stringBuilder.append("'").append(dependencyMaxCodes.get(i).getCode()).append("',");
            }
        }

        return stringBuilder.toString();
    }

    private List<FlinkJobDependency> transformFlinkJobDependency(int jobId, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {
        String sql = JobConf.generateQueryFlinkJobByIdSql(flinkConf.getMysqlJobTableName(), jobId);
        final List<FlinkJob> flinkJobs = mySQLJobUtil.queryList(sql, FlinkJob.class, true);
        return FlinkJobDependency.tranform(flinkJobs.get(0).getDependencyConf());


    }


}
