package jobDealer;

import model.FlinkJobTask;
import server.queue.BlockCallerPolicy;
import server.queue.GroupPriorityQueue;
import taskPlugins.AbstractTask;
import taskPlugins.TaskChannel;
import taskPlugins.TaskPluginManager;
import threadfactory.CustomThreadFactory;

import java.util.concurrent.*;

public class JobSubmitDealer implements Runnable {
    private GroupPriorityQueue groupPriorityQueue;

    private PriorityBlockingQueue<FlinkJobTask> queue = null;

    private ExecutorService jobSubmitConcurrentService;

    private int jobSubmitConcurrent = 1;
    private String jobResource = null;
    private TaskPluginManager taskPluginManager;
//    private AbstractTask task;


    public JobSubmitDealer(GroupPriorityQueue groupPriorityQueue) {
        this.groupPriorityQueue = groupPriorityQueue;
        this.queue = groupPriorityQueue.getQueue();
        this.jobResource = groupPriorityQueue.getJobResource();
        this.jobSubmitConcurrentService =
                new ThreadPoolExecutor(jobSubmitConcurrent, jobSubmitConcurrent, 60L, TimeUnit.SECONDS,
                        new SynchronousQueue<>(true),
                        new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmitConcurrent"),
                        new BlockCallerPolicy());
        this.taskPluginManager = new TaskPluginManager();
        taskPluginManager.installPlugin();
    }

    @Override
    public void run() {
        while (true) {
            try {
                FlinkJobTask jobClient = queue.take();


                //提交任务
                jobSubmitConcurrentService.submit(() -> {
                    submitJob(jobClient);
                });
            } catch (Exception e) {
//                LOGGER.error("", e);
            }
        }
    }

    private void submitJob(FlinkJobTask jobClient) {
        TaskChannel taskChannel = taskPluginManager.getTaskChannelMap().get(jobClient.getResourceName());
        final JobDealer jobDealer = groupPriorityQueue.getJobDealer();

        AbstractTask task = taskChannel.createTask(jobClient,jobDealer.getFlinkConf(),jobDealer.getMySQLUtil());
        task.init();
        try {
            task.handle();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
