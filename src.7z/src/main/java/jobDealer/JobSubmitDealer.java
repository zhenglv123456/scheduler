package jobDealer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import conf.FlinkConf;
import model.FlinkJobTask;
import model.FlinkJobTaskLog;
import server.queue.BlockCallerPolicy;
import server.queue.GroupPriorityQueue;
import taskPlugins.AbstractTask;
import taskPlugins.TaskChannel;
import taskPlugins.TaskPluginManager;
import threadfactory.CustomThreadFactory;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.*;

public class JobSubmitDealer implements Runnable {
    private GroupPriorityQueue groupPriorityQueue;

    private PriorityBlockingQueue<FlinkJobTask> queue = null;

    private ExecutorService jobSubmitConcurrentService;

    private int jobSubmitConcurrent = 1;
    private String jobResource = null;
    private TaskPluginManager taskPluginManager;
//    private AbstractTask task;


    public JobSubmitDealer(GroupPriorityQueue groupPriorityQueue) {
        this.groupPriorityQueue = groupPriorityQueue;
        this.queue = groupPriorityQueue.getQueue();
        this.jobResource = groupPriorityQueue.getJobResource();
        this.jobSubmitConcurrentService =
                new ThreadPoolExecutor(jobSubmitConcurrent, jobSubmitConcurrent, 60L, TimeUnit.SECONDS,
                        new SynchronousQueue<>(true),
                        new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmitConcurrent"),
                        new BlockCallerPolicy());
        this.taskPluginManager = new TaskPluginManager();
        taskPluginManager.installPlugin();
    }

    @Override
    public void run() {
        while (true) {
            try {
                FlinkJobTask jobClient = queue.take();


                //提交任务
                jobSubmitConcurrentService.submit(() -> {
                    try {
                        submitJob(jobClient);
                    } catch (Exception e) {
                        e.printStackTrace();
                        queue.add(jobClient);
                    }
                });
            } catch (Exception e) {
//                LOGGER.error("", e);
            }
        }
    }

    private void submitJob(FlinkJobTask jobClient) throws Exception {
        TaskChannel taskChannel = taskPluginManager.getTaskChannelMap().get(jobClient.getResourceName());
        final JobDealer jobDealer = groupPriorityQueue.getJobDealer();

        AbstractTask task = taskChannel.createTask(jobClient,jobDealer.getFlinkConf(),jobDealer.getMySQLUtil());
        task.init();

           String resultData =  task.handle();
            System.out.println(resultData);
            // {"errors":["Internal server error.","<Exception on server side:\r\norg.apache.flink.table.gateway.api.utils.SqlGatewayException:"]}

            final MySQLUtil mySQLUtil = groupPriorityQueue.getJobDealer().getMySQLUtil();
            final FlinkConf flinkConf = groupPriorityQueue.getJobDealer().getFlinkConf();

            //{"results":{"columns":[],"data":[]},"resultType":"NOT_READY","nextResultUri":"/v1/sessions/04481d3a-f3e9-478a-b1ef-d851880339e2/operations/07313cbb-bd86-46eb-9211-9fefcc43b139/result/0"}
            // 如果结果是错误的，更新任务执行状态为错误3，并将错误记录在任务执行记录日志中
            final JSONObject resultDataJsonObject = JSON.parseObject(resultData);
            if(resultDataJsonObject.containsKey("errors")){
                final FlinkJobTaskLog flinkJobTaskLog = new FlinkJobTaskLog();
                flinkJobTaskLog.setJobTaskCode(jobClient.getCode());
                flinkJobTaskLog.setMsg(resultData);
                mySQLUtil.insert("flink_job_task_log",true,flinkJobTaskLog);
                jobClient.setStatus("3");
                jobClient.setStartTime(String.valueOf(TimeUtil.localDateTimeToMilliSecond(LocalDateTime.now())));
                jobClient.setUpdateTime(String.valueOf(TimeUtil.localDateTimeToMilliSecond(LocalDateTime.now())));
                final HashMap<String, Object> objectObjectHashMap = new HashMap<>();
                objectObjectHashMap.put("id", jobClient.getId());
                objectObjectHashMap.put("code", jobClient.getCode());
                mySQLUtil.upsert(flinkConf.getMysqlJobTaskTableName(),true,jobClient,objectObjectHashMap);
            }else{
                // 如果结果不是错误，更新任务执行状态为执行中2
                jobClient.setStatus("2");
                jobClient.setStartTime(String.valueOf(TimeUtil.localDateTimeToMilliSecond(LocalDateTime.now())));
                final HashMap<String, Object> objectObjectHashMap = new HashMap<>();
                objectObjectHashMap.put("id", jobClient.getId());
                objectObjectHashMap.put("code", jobClient.getCode());
                mySQLUtil.upsert(flinkConf.getMysqlJobTaskTableName(),true,jobClient,objectObjectHashMap);

            }






    }
}
