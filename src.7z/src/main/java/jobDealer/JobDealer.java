package jobDealer;

import com.google.common.collect.Maps;
import conf.FlinkConf;
import model.FlinkJobTask;
import server.queue.GroupPriorityQueue;
import utils.MySQLUtil;

import java.util.Map;

public class JobDealer {
    /**
     * key: jobResource, 计算引擎类型
     * value: queue
     */
    private Map<String, GroupPriorityQueue> priorityQueueMap = Maps.newConcurrentMap();

    private FlinkConf flinkConf;
    private MySQLUtil mySQLUtil;

    public JobDealer(FlinkConf flinkConf, MySQLUtil mySQLJobUtil) {
        this.flinkConf = flinkConf;
        this.mySQLUtil = mySQLJobUtil;
    }

    public void init(){

    }

    public FlinkConf getFlinkConf() {
        return flinkConf;
    }

    public MySQLUtil getMySQLUtil() {
        return mySQLUtil;
    }

    public void addSubmitJob(FlinkJobTask jobClient) {
        String jobResource = jobClient.getResourceName();
//        jobClient.setCallBack((jobStatus) -> {
//            updateJobStatus(jobClient.getJobId(), jobStatus);
//        });

        //加入节点的优先级队列
        this.addGroupPriorityQueue(jobResource, jobClient, true, true);
    }

    public boolean addGroupPriorityQueue(String jobResource, FlinkJobTask jobClient, boolean judgeBlock, boolean insert) {
        try {
            GroupPriorityQueue groupPriorityQueue = getGroupPriorityQueue(jobResource);
            boolean rs = groupPriorityQueue.add(jobClient, judgeBlock, insert);
//            if (!rs) {
//                saveCache(jobClient, jobResource, EJobCacheStage.DB.getStage(), insert);
//            }
            return rs;
        } catch (Exception e) {
//            LOGGER.error("", e);
//            dealSubmitFailJob(jobClient.getJobId(), e.toString());
            return false;
        }
    }

    public GroupPriorityQueue getGroupPriorityQueue(String jobResource) {
        GroupPriorityQueue groupPriorityQueue = priorityQueueMap.computeIfAbsent(jobResource, k -> GroupPriorityQueue.builder()
//                .setApplicationContext(applicationContext)
                .setJobResource(jobResource)
                .setJobDealer(this)
                .build());
        return groupPriorityQueue;
    }
}
