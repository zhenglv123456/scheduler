package jobDealer;

import com.google.common.collect.Maps;
import conf.FlinkConf;
import model.FlinkJob;
import model.FlinkJobTask;
import server.queue.GroupPriorityQueue;
import utils.MySQLUtil;

import java.util.Map;

public class JobDealer {
    /**
     * key: jobResource, 计算引擎类型
     * value: queue
     */
    private Map<String, GroupPriorityQueue> priorityQueueMap = Maps.newConcurrentMap();

    private FlinkConf flinkConf;
    private MySQLUtil mySQLUtil;

    public JobDealer(FlinkConf flinkConf, MySQLUtil mySQLJobUtil) {
        this.flinkConf = flinkConf;
        this.mySQLUtil = mySQLJobUtil;
    }

    public Map<String, GroupPriorityQueue> getPriorityQueueMap() {
        return priorityQueueMap;
    }

    public void init(){

    }

    public FlinkConf getFlinkConf() {
        return flinkConf;
    }

    public MySQLUtil getMySQLUtil() {
        return mySQLUtil;
    }

    public void addSubmitJob(FlinkJobTask jobClient,String handlerType) {
        String jobResource = jobClient.getResourceName();
//        jobClient.setCallBack((jobStatus) -> {
//            updateJobStatus(jobClient.getJobId(), jobStatus);
//        });

        //加入节点的优先级队列
        this.addGroupPriorityQueue(jobResource, jobClient, true, true,handlerType);
    }

    public boolean addGroupPriorityQueue(String jobResource, FlinkJobTask jobClient, boolean judgeBlock, boolean insert,String handlerType) {
        try {
            GroupPriorityQueue groupPriorityQueue = getGroupPriorityQueue(jobResource,handlerType);
            boolean rs = groupPriorityQueue.add(jobClient, judgeBlock, insert,handlerType);
//            if (!rs) {
//                saveCache(jobClient, jobResource, EJobCacheStage.DB.getStage(), insert);
//            }
            return rs;
        } catch (Exception e) {
//            LOGGER.error("", e);
//            dealSubmitFailJob(jobClient.getJobId(), e.toString());
            return false;
        }
    }
    private void addJobGroupPriorityQueue(String resourceName, FlinkJob flinkJob, boolean judgeBlock, boolean insert, String handlerType) {

        try {
            GroupPriorityQueue groupPriorityQueue = getGroupPriorityQueue(resourceName,handlerType);
            boolean rs = groupPriorityQueue.addJob(flinkJob, judgeBlock, insert,handlerType);
//
        } catch (Exception e) {
//            LOGGER.error("", e);
//            dealSubmitFailJob(jobClient.getJobId(), e.toString());
        }
    }

    public GroupPriorityQueue getGroupPriorityQueue(String jobResource,String handlerType) {
        GroupPriorityQueue groupPriorityQueue = priorityQueueMap.computeIfAbsent(jobResource, k -> GroupPriorityQueue.builder()
//                .setApplicationContext(applicationContext)
                .setJobResource(jobResource)
                .setJobDealer(this)
                .build(handlerType));
        return groupPriorityQueue;
    }



    public void addCheckRunningTaskStatusJob(FlinkJobTask flinkJobTask, String handlerType) {
        addSubmitJob(flinkJobTask,handlerType);
    }

    public boolean isExecuteSuccessDependencyJobTaskQueueEmpty(FlinkJobTask dependencyFlinkJobTask, String code) {
        GroupPriorityQueue groupPriorityQueue = getGroupPriorityQueue(dependencyFlinkJobTask.getResourceName(), code);
        return groupPriorityQueue.isQueueEmpty();
    }

    public void addScanDelayJobsAndGenTasksJob(FlinkJob flinkJob, String handlerType) {

        String resourceName = flinkJob.getResourceName();
        this.addJobGroupPriorityQueue(resourceName, flinkJob, true, true,handlerType);

    }


    public void addDependencyCheckJob(FlinkJobTask dependencyFlinkJobTask, String handlerType) {
        addSubmitJob(dependencyFlinkJobTask,handlerType);

    }

    public void addScanJobsAndGenTasksJob(FlinkJob flinkJob, String handlerType) {
        String resourceName = flinkJob.getResourceName();
        this.addJobGroupPriorityQueue(resourceName, flinkJob, true, true,handlerType);

    }
}
