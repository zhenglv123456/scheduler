package jobDealer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import conf.FlinkConf;
import enums.TaskAction;
import enums.TaskState;
import model.FlinkJobTask;
import model.FlinkJobTaskLog;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import server.queue.BlockCallerPolicy;
import server.queue.GroupPriorityQueue;
import taskPlugins.AbstractTask;
import taskPlugins.TaskChannel;
import taskPlugins.TaskPluginManager;
import threadfactory.CustomThreadFactory;
import utils.FlinkStatusUtil;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.*;

public class JobCheckRunningTaskStatusDealer implements Runnable {
    private GroupPriorityQueue groupPriorityQueue;

    private PriorityBlockingQueue<FlinkJobTask> checkRunningTaskStatusQueue = null;

    private ExecutorService jobSubmitConcurrentService;

    private int jobSubmitConcurrent = 1;
    private String jobResource = null;
    private TaskPluginManager taskPluginManager;
//    private AbstractTask task;


    public JobCheckRunningTaskStatusDealer(GroupPriorityQueue groupPriorityQueue) {
        this.groupPriorityQueue = groupPriorityQueue;
        this.checkRunningTaskStatusQueue = groupPriorityQueue.getCheckRunningTaskStatusQueue();
        this.jobResource = groupPriorityQueue.getJobResource();
        this.jobSubmitConcurrentService =
                new ThreadPoolExecutor(jobSubmitConcurrent, jobSubmitConcurrent, 60L, TimeUnit.SECONDS,
                        new SynchronousQueue<>(true),
                        new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmitConcurrent"),
                        new BlockCallerPolicy());
        this.taskPluginManager = new TaskPluginManager();
        taskPluginManager.installPlugin();
    }

    @Override
    public void run() {
        while (true) {
            try {
                FlinkJobTask jobClient = checkRunningTaskStatusQueue.take();


                //提交任务
                jobSubmitConcurrentService.submit(() -> {
                    try {
                        submitJob(jobClient);
                    } catch (Exception e) {
                        e.printStackTrace();
                        checkRunningTaskStatusQueue.add(jobClient);
                    }
                });
            } catch (Exception e) {
//                LOGGER.error("", e);
            } finally {
                if (groupPriorityQueue.getCheckRunningTaskStatusQueue().size() == 0) {
                    groupPriorityQueue.setQueueEmpty(true);
                }
            }
        }
    }

    private void submitJob(FlinkJobTask flinkJobTask) throws Exception {

        final MySQLUtil mySQLJobUtil = groupPriorityQueue.getJobDealer().getMySQLUtil();
        final FlinkConf flinkConf = groupPriorityQueue.getJobDealer().getFlinkConf();
        try {
            final String jobID = FlinkStatusUtil.getJobID(flinkConf.getFlinkJobsUrl(),flinkJobTask.getCode());
            if(StringUtils.isBlank(jobID)){
                // 没有查到jobid
                return;
            }
            final String jobState = FlinkStatusUtil.getJobState(flinkConf.getFlinkJobsUrl(), jobID);
            //FAILED ,  FINISHED
            if("FINISHED".equals(jobState)){
                // 如果查询到任务执行完成，更新状态为4 ，
                flinkJobTask.setStatus(String.valueOf(TaskState.SUCCESS.getCode()));
            }else if("FAILED".equals(jobState)){
                // 如果查询到任务执行错误，更新状态为3
                flinkJobTask.setStatus(String.valueOf(TaskState.FAILED.getCode()));
                // 根据code中的第一位表示重试次数，如果重试次数不大于5，再次生成一条执行记录
                Integer retry_count = Integer.valueOf(flinkJobTask.getCode().substring(0,1));
                if(retry_count<5){
                    createRetryJobTask(flinkJobTask,retry_count+1,mySQLJobUtil,flinkConf);
                }


            }
            flinkJobTask.setUpdateTime(String.valueOf(TimeUtil.localDateTimeToMilliSecond(LocalDateTime.now())));
            final HashMap<String, Object> objectObjectHashMap = new HashMap<>();
            objectObjectHashMap.put("id", flinkJobTask.getId());
            objectObjectHashMap.put("code", flinkJobTask.getCode());
            mySQLJobUtil.upsert(flinkConf.getMysqlJobTaskTableName(),true,flinkJobTask,objectObjectHashMap);


        } catch (IOException e) {
            e.printStackTrace();
        }







    }

    private void createRetryJobTask(FlinkJobTask flinkJobTask, int retry_count, MySQLUtil mySQLJobUtil, FlinkConf flinkConf) {

        FlinkJobTask flinkJobTask1 = new FlinkJobTask();
        flinkJobTask1.setCode(retry_count+ RandomStringUtils.randomAlphanumeric(8)+flinkJobTask.getJobId()+flinkJobTask.getScheduleTime());

        flinkJobTask1.setScheduleTime(flinkJobTask.getScheduleTime());
        flinkJobTask1.setJobId(flinkJobTask.getJobId());
        flinkJobTask1.setStatus(TaskState.DEPENDENCY.getCode());
        flinkJobTask1.setAction(TaskAction.GENERATEBYFAILED.getCode());
        mySQLJobUtil.insert(flinkConf.getMysqlJobTaskTableName(),true,flinkJobTask1);
    }
}
