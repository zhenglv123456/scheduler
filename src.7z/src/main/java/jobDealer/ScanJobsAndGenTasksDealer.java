package jobDealer;

import conf.FlinkConf;
import enums.TaskAction;
import enums.TaskState;
import model.FlinkJob;
import model.FlinkJobTask;
import org.apache.commons.lang3.RandomStringUtils;
import server.queue.BlockCallerPolicy;
import server.queue.GroupPriorityQueue;
import taskPlugins.TaskPluginManager;
import threadfactory.CustomThreadFactory;
import utils.CronUtils;
import utils.MySQLUtil;
import utils.TimeUtil;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.*;

public class ScanJobsAndGenTasksDealer implements Runnable {
    private GroupPriorityQueue groupPriorityQueue;

    private PriorityBlockingQueue<FlinkJob> scanJobsAndGenTasksQueue = null;

    private ExecutorService jobSubmitConcurrentService;

    private int jobSubmitConcurrent = 1;
    private String jobResource = null;
    private TaskPluginManager taskPluginManager;
//    private AbstractTask task;


    public ScanJobsAndGenTasksDealer(GroupPriorityQueue groupPriorityQueue) {
        this.groupPriorityQueue = groupPriorityQueue;
        this.scanJobsAndGenTasksQueue = groupPriorityQueue.getScanJobsAndGenTasksQueue();
        this.jobResource = groupPriorityQueue.getJobResource();
        this.jobSubmitConcurrentService =
                new ThreadPoolExecutor(jobSubmitConcurrent, jobSubmitConcurrent, 60L, TimeUnit.SECONDS,
                        new SynchronousQueue<>(true),
                        new CustomThreadFactory(this.getClass().getSimpleName() + "_" + jobResource + "_JobSubmitConcurrent"),
                        new BlockCallerPolicy());
        this.taskPluginManager = new TaskPluginManager();
        taskPluginManager.installPlugin();
    }

    @Override
    public void run() {
        while (true) {
            try {
                FlinkJob jobClient = scanJobsAndGenTasksQueue.take();


                //提交任务
                jobSubmitConcurrentService.submit(() -> {
                    try {
                        submitJob(jobClient);
                    } catch (Exception e) {
                        e.printStackTrace();
                        scanJobsAndGenTasksQueue.add(jobClient);
                    }
                });
            } catch (Exception e) {
//                LOGGER.error("", e);
            } finally {
                if (groupPriorityQueue.getScanJobsAndGenTasksQueue().size() == 0) {
                    groupPriorityQueue.setQueueEmpty(true);
                }
            }
        }
    }

    private void submitJob(FlinkJob flinkJob) throws Exception {
        final MySQLUtil mySQLUtil = groupPriorityQueue.getJobDealer().getMySQLUtil();
        final FlinkConf flinkConf = groupPriorityQueue.getJobDealer().getFlinkConf();
        final LocalDateTime currScheduleTime = CronUtils.scheduleTimeOf(flinkJob.getCron(), TimeUtil.timestampToLocalDateTime(flinkJob.getCurrTime()));
        final LocalDateTime nextScheduleTime = CronUtils.nextScheduleTimeOf(flinkJob.getCron(), TimeUtil.timestampToLocalDateTime(flinkJob.getCurrTime()));

        createFlinkJobTask(flinkJob, currScheduleTime,mySQLUtil,flinkConf);
        updateFlinkJobNextScheduleTime(flinkJob, currScheduleTime, nextScheduleTime,mySQLUtil,flinkConf);

    }

    private void updateFlinkJobNextScheduleTime(FlinkJob flinkJob, LocalDateTime currScheduleTime, LocalDateTime nextScheduleTime, MySQLUtil mySQLUtil, FlinkConf flinkConf) {
        final HashMap<String, Object> stringObjectHashMap = new HashMap<>();
        stringObjectHashMap.put("id", flinkJob.getId());
//        stringObjectHashMap.put("nextScheduleTime",);
        flinkJob.setNextScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(nextScheduleTime)));
        flinkJob.setPreScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));

        mySQLUtil.update(flinkConf.getMysqlJobTableName(), true, flinkJob, stringObjectHashMap);
    }

    private void createFlinkJobTask(FlinkJob flinkJob, LocalDateTime currScheduleTime, MySQLUtil mySQLUtil, FlinkConf flinkConf) {

        final FlinkJobTask flinkJobTask = new FlinkJobTask();
        flinkJobTask.setCode("1" + RandomStringUtils.randomAlphanumeric(8) + flinkJob.getId() + String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));
        flinkJobTask.setScheduleTime(String.valueOf(TimeUtil.localDateTimeToSeconds(currScheduleTime)));
        flinkJobTask.setJobId(flinkJob.getId());
        flinkJobTask.setStatus(TaskState.DEPENDENCY.getCode());
        flinkJobTask.setAction(TaskAction.NORMAL.getCode());
        flinkJobTask.setPriority(flinkJob.getPriority());
        mySQLUtil.insert(flinkConf.getMysqlJobTaskTableName(), true, flinkJobTask);
    }

}
